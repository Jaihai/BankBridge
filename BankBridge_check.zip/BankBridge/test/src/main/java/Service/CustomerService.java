package Service;

import dto.*;

import java.util.List;

public interface CustomerService {
    Long create(CreateCustomerDto dto);
    void update(Long id, UpdateCustomerDto dto);
    List<CustomerDto> listAll();
    CustomerDto get(Long id);
    void delete(Long id);

    LoginResponseDto login(LoginRequestDto dto);

    // Projections/related
    List<AccountDto> getAllAccounts(Long customerId);
    AddressDto findAddress(Long customerId);
}