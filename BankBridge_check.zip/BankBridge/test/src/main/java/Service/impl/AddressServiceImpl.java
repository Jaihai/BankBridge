package Service.impl;

import Service.AddressService;
import Mapper.AddressMapper;
import Model.Customer;
import Repository.CustomerRepository;
import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AddressServiceImpl implements AddressService {

    private final CustomerRepository customerRepo;
    private final AddressMapper addressMapper;

    public AddressServiceImpl(CustomerRepository customerRepo, AddressMapper addressMapper) {
        this.customerRepo = customerRepo;
        this.addressMapper = addressMapper;
    }

    @Override
    public Long create(CreateAddressDto dto) {
        // Treat "create" as storing address fields on an existing Customer
        Long customerId = dto.getCustomerId();
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));

        addressMapper.applyCreate(dto, c);
        customerRepo.save(c);
        return extractCustomerId(c);
    }

    @Override
    public void updateByCustomerId(Long customerId, UpdateAddressDto dto) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));

        addressMapper.applyUpdate(dto, c);
        customerRepo.save(c);
    }

    @Override
    public void deleteByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));

        // Clear address fields (prefer camelCase; fallback to snake_case if your model uses it)
        try {
            c.setAddressLine(null);
            c.setCity(null);
            c.setState(null);
            c.setPostalCode(null);
            c.setCountry(null);
        } catch (Throwable ignore) {
            try { c.setAddressLine(null); } catch (Throwable ignored) {}
            try { c.setCity(null); } catch (Throwable ignored) {}
            try { c.setState(null); } catch (Throwable ignored) {}
            try { c.setPostalCode(null); } catch (Throwable ignored) {}
            try { c.setCountry(null); } catch (Throwable ignored) {}
        }

        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AddressDto> listAll() {
        return customerRepo.findAll().stream().map(addressMapper::toDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));
        return addressMapper.toDto(c);
    }

    private Long extractCustomerId(Customer c) {
        // Try conventional getId()
        try {
            Object val = c.getClass().getMethod("getId").invoke(c);
            if (val instanceof Long l) return l;
            if (val instanceof Integer i) return i.longValue();
        } catch (Throwable ignored) {}
        // Fallback to snake_case getCustomer_id()
        try {
            Object val = c.getClass().getMethod("getCustomer_id").invoke(c);
            if (val instanceof Integer i) return i.longValue();
            if (val instanceof Long l) return l;
        } catch (Throwable ignored) {}
        // If your model has a different getter (e.g., getCustomerId()), try that:
        try {
            Object val = c.getClass().getMethod("getCustomerId").invoke(c);
            if (val instanceof Long l) return l;
            if (val instanceof Integer i) return i.longValue();
        } catch (Throwable ignored) {}
        return null;
    }
}