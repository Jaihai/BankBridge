package Repository;

import Model.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {
    // Make sure this returns Optional<Account> so you can call orElseThrow(...)
    Optional<Account> findByAccountNumber(String accountNumber);

    // If you need to load a customer's accounts by customer id (Long)
    List<Account> findAllByCustomerId(Long customerId);
}