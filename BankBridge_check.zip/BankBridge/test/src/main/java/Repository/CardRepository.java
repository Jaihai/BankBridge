package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.Card;

public interface CardRepository extends JpaRepository <Card,Long>{

}
