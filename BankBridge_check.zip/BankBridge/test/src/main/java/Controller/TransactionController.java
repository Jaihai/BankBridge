package Controller;

import Service.TransactionService;
import dto.*;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/transaction")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) { this.transactionService = transactionService; }

    // POST /bankapi/v1/transaction/deposit
    @PostMapping("/deposit")
    public ResponseEntity<String> deposit(@Valid @RequestBody DepositRequest req) {
        String msg = transactionService.deposit(req);
        return ResponseEntity.status(201).body(msg); // "Record Created Successfully"
    }

    // POST /bankapi/v1/transaction/withdraw
    @PostMapping("/withdraw")
    public ResponseEntity<String> withdraw(@Valid @RequestBody WithdrawRequest req) {
        String msg = transactionService.withdraw(req);
        return ResponseEntity.ok(msg); // "Record Modified Successfully"
    }

    // POST /bankapi/v1/transaction/fundtransfer
    @PostMapping("/fundtransfer")
    public ResponseEntity<String> fundTransfer(@Valid @RequestBody FundTransferRequest req) {
        String msg = transactionService.fundTransfer(req);
        return ResponseEntity.ok(msg); // "Record Modified Successfully"
    }

    // GET /bankapi/v1/transaction/summary?from=...&to=...
    @GetMapping("/summary")
    public ResponseEntity<List<TransactionDto>> summary(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(transactionService.summary(from, to));
    }
}