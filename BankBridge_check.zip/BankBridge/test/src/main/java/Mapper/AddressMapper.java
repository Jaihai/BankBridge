package Mapper;

import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import Model.Customer;

import java.util.ArrayList;
import java.util.List;

public class AddressMapper {

    // ===== "Entity" -> DTO =====
    // Since there is no Address entity, we read from Customer's address fields.
    public AddressDto toDto(Customer c) {
        if (c == null) return null;
        Long customerId = null;
        // Adjust these two lines to match your Customer id getter (Integer vs Long)
        try {
            // If Customer has getCustomer_id() returning Integer (snake_case style)
            Long idInt = c.getCustomerId();
            customerId = (idInt != null) ? idInt.longValue() : null;
        } catch (Throwable ignore) {
            // Or if Customer has conventional getId() returning Long/Integer
            try {
                Object val = c.getClass().getMethod("getId").invoke(c);
                if (val instanceof Integer i) customerId = i.longValue();
                else if (val instanceof Long l) customerId = l;
            } catch (Throwable ignored) {}
        }

        return new AddressDto(
                /* id (Address id) */ null,          // no Address id; keep null
                customerId,
                c.getAddressLine(),
                c.getCity(),
                c.getState(),
                c.getPostalCode(),
                c.getCountry()
        );
    }

    // If you ever need a list, you’ll likely list Customers and map each one
    public List<AddressDto> toDtoList(List<Customer> customers) {
        if (customers == null || customers.isEmpty()) return new ArrayList<>();
        List<AddressDto> out = new ArrayList<>(customers.size());
        for (Customer c : customers) {
            out.add(toDto(c));
        }
        return out;
    }

    // ===== DTO -> "Entity" (apply changes to Customer) =====
    public void applyCreate(CreateAddressDto dto, Customer customer) {
        if (dto == null || customer == null) return;
        customer.setAddressLine(dto.getAddressLine());
        customer.setCity(dto.getCity());
        customer.setState(dto.getState());
        customer.setPostalCode(dto.getPostalCode());
        customer.setCountry(dto.getCountry());
    }

    public void applyUpdate(UpdateAddressDto dto, Customer customer) {
        if (dto == null || customer == null) return;
        customer.setAddressLine(dto.getAddressLine());
        customer.setCity(dto.getCity());
        customer.setState(dto.getState());
        customer.setPostalCode(dto.getPostalCode());
        customer.setCountry(dto.getCountry());
    }
}