package Mapper;

import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import Model.Account;
import Model.Customer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class AccountMapper {

    // ===== Entity -> DTO =====
    public AccountDto toDto(Account a) {
        if (a == null) return null;

        // id: Integer -> Long
        Long id = a.getAccount_id() != null ? a.getAccount_id().longValue() : null;

        // customerId: from nested Customer (supports either getCustomer_id() or getId())
        Long customerId = extractCustomerId(a.getCustomer_id());

        // accountNumber: Integer -> String (DTO uses String)
        String accountNumber = a.getAccount_number() != null ? String.valueOf(a.getAccount_number()) : null;

        // balance: Double -> BigDecimal
        BigDecimal balance = a.getBalance() != null ? BigDecimal.valueOf(a.getBalance()) : BigDecimal.ZERO;

        return new AccountDto(
                id,
                customerId,
                accountNumber,
                a.getAccount_type(),
                a.getCurrency(),
                balance,
                a.getStatus()
        );
    }

    public List<AccountDto> toDtoList(List<Account> accounts) {
        if (accounts == null || accounts.isEmpty()) return new ArrayList<>();
        List<AccountDto> out = new ArrayList<>(accounts.size());
        for (Account a : accounts) {
            out.add(toDto(a));
        }
        return out;
    }

    // ===== DTO -> Entity =====
    public Account fromCreate(CreateAccountDto dto, Customer customer, String generatedAccountNumber) {
        if (dto == null) return null;

        Account a = new Account(null, customer, null, null, generatedAccountNumber, generatedAccountNumber, null, generatedAccountNumber, null, null);
        // associate customer
        a.setCustomer_id(customer);

        // your entity expects Integer for account_number; convert from generated String
        a.setAccount_number(safeParseInt(generatedAccountNumber));

        a.setAccount_type(dto.getAccountType());
        a.setCurrency(dto.getCurrency());

        // initialDeposit BigDecimal -> Double (entity)
        a.setBalance(dto.getInitialDeposit() != null ? dto.getInitialDeposit().doubleValue() : 0.0d);

        a.setStatus("OPEN");
        // opened_at / closed_at: set in service or via @PrePersist in the entity if you add it
        return a;
    }

    public void applyUpdate(UpdateAccountDto dto, Account entity) {
        if (dto == null || entity == null) return;
        entity.setAccount_type(dto.getAccountType());
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
    }

    // ===== helpers =====
    private Integer safeParseInt(String value) {
        if (value == null) return null;
        try {
            return Integer.valueOf(value);
        } catch (NumberFormatException ex) {
            // fallback: deterministic numeric representation (avoid collisions if possible)
            return Math.abs(value.hashCode());
        }
    }

    private Long extractCustomerId(Customer c) {
        if (c == null) return null;
        // Prefer your snake_case getter (fits your Model style)
        try {
            Long cid = c.getCustomerId(); // if exists
            return cid != null ? cid.longValue() : null;
        } catch (NoSuchMethodError | Exception ignored) {
            // Fallback to conventional getter if your Customer uses getId()
            try {
                java.lang.reflect.Method m = c.getClass().getMethod("getId");
                Object val = m.invoke(c);
                if (val instanceof Integer i) return i.longValue();
                if (val instanceof Long l) return l;
            } catch (Exception e) {
                // ignore; return null
            }
        }
        return null;
    }
}