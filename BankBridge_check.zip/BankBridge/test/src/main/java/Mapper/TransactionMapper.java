package Mapper;

import Model.Account;
import Model.Transaction;
import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;

import java.util.List;

public class TransactionMapper {

    // ===== Entity -> DTO =====
    public TransactionDto toDto(Transaction t) {
        if (t == null) return null;

        Long accountNo = (t.getAccount_id() != null) ? t.getAccount_id().getAccount_id() : null;

        // Adjust the constructor below if your TransactionDto signature differs
        return new TransactionDto(
        );
    }

    public List<TransactionDto> toDtoList(List<Transaction> txns) {
        return MapperUtils.mapList(txns, this::toDto);
    }

    // ===== Factory helpers from request DTOs =====
    // The service should set balance_after AFTER updating the account, then persist.

    public Transaction creditFromDeposit(Account account, DepositRequest req) {
        Transaction t = new Transaction();
        t.setAccount_id(account);
        t.setTxn_type("credit");
        t.setAmount(req.getAmount());
        t.setCurrency(account.getCurrency());     // keep as String per your entity
        t.setReference("DEPOSIT");
        t.setDescription("Cash deposit");
        // posted_at is typically set by DB default or service; set here if you want:
        // t.setPosted_at(LocalDate.now());
        return t;
    }

    public Transaction debitFromWithdraw(Account account, WithdrawRequest req) {
        Transaction t = new Transaction();
        t.setAccount_id(account);
        t.setTxn_type("debit");
        t.setAmount(req.getAmount());
        t.setCurrency(account.getCurrency());
        t.setReference("WITHDRAW");
        t.setDescription("Cash withdrawal");
        return t;
    }

    public Transaction debitFromTransfer(Account from, FundTransferRequest req) {
        Transaction t = new Transaction();
        t.setAccount_id(from);
        t.setTxn_type("debit");
        t.setAmount(req.getAmount());
        t.setCurrency(from.getCurrency());
        t.setReference("TRANSFER");
        t.setDescription("Fund transfer - debit");
        return t;
    }

    public Transaction creditFromTransfer(Account to, FundTransferRequest req) {
        Transaction t = new Transaction();
        t.setAccount_id(to);
        t.setTxn_type("credit");
        t.setAmount(req.getAmount());
        t.setCurrency(to.getCurrency());
        t.setReference("TRANSFER");
        t.setDescription("Fund transfer - credit");
        return t;
    }
}