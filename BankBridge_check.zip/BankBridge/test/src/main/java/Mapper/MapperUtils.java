package Mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

final class MapperUtils {

    private MapperUtils() { }

    static <S, T> List<T> mapList(List<S> source, Function<S, T> mapper) {
        if (source == null || source.isEmpty()) return new ArrayList<>();
        List<T> out = new ArrayList<>(source.size());
        for (S s : source) {
            out.add(mapper.apply(s));
        }
        return out;
    }
}