package Model;

 
import java.time.LocalDate;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
 
//Table Creation for Java Class
@Entity
@Table(name = "loan-payment")
public class LoanPayment {
	//create the column
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private Long PaymentId;
	@Column(name= "due-date",unique = true, nullable  = false)
	private LocalDate dueDate;
	@Column(name= "paid-date",unique = true, nullable  = false)
	private LocalDate paidDate;
	@Column(name= "amount-paid",unique = true, nullable  = false)
	private int amountPaid;
	@Column(name= "penality-amount",unique = true, nullable  = false)
	private int penlityAmount;
	@Column(name= "status",unique = true, nullable  = false)
	private String status;
	//Association
	@ManyToOne
	@JoinColumn(name = "loan_id", nullable = false)
	private Loan loan;
	//Default Constructor
	public LoanPayment() {
	}
	//Parameterized Constructor
 
	public LoanPayment(Long paymentId, LocalDate dueDate, LocalDate paidDate, int amountPaid, int penlityAmount,
			String status, Loan loan) {
		PaymentId = paymentId;
		this.dueDate = dueDate;
		this.paidDate = paidDate;
		this.amountPaid = amountPaid;
		this.penlityAmount = penlityAmount;
		this.status = status;
		this.loan = loan;
	}
	//Getters And Setters
 
	public Long getPaymentId() {
		return PaymentId;
	}
 
	public void setPaymentId(Long paymentId) {
		PaymentId = paymentId;
	}
 
	public LocalDate getDueDate() {
		return dueDate;
	}
 
	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}
 
	public LocalDate getPaidDate() {
		return paidDate;
	}
 
	public void setPaidDate(LocalDate paidDate) {
		this.paidDate = paidDate;
	}
 
	public int getAmountPaid() {
		return amountPaid;
	}
 
	public void setAmountPaid(int amountPaid) {
		this.amountPaid = amountPaid;
	}
 
	public int getPenlityAmount() {
		return penlityAmount;
	}
 
	public void setPenlityAmount(int penlityAmount) {
		this.penlityAmount = penlityAmount;
	}
 
	public String getStatus() {
		return status;
	}
 
	public void setStatus(String status) {
		this.status = status;
	}
 
	public Loan getLoan() {
		return loan;
	}
 
	public void setLoan(Loan loan) {
		this.loan = loan;
	}
	//ToString
 
	@Override
	public String toString() {
		return "LoanPayment [PaymentId=" + PaymentId + ", dueDate=" + dueDate + ", paidDate=" + paidDate
				+ ", amountPaid=" + amountPaid + ", penlityAmount=" + penlityAmount + ", status=" + status + ", loan="
				+ loan + "]";
	}




 
}