package Model;

 
import java.time.LocalDate;
import java.util.List;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
 
@Entity
@Table(name ="loan")
public class Loan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long loanId;
	@Column(name = "loan-Number",unique = true, nullable = false)
	private String loanNumber;
	@Column(name = "loan-type",unique = true, nullable = false)
	private String loanType;
	@Column(name = "principal-Amount",unique = true, nullable = false)
	private Double principalAmount;
	@Column(name = "interest-rate",unique = true, nullable = false) 
	private Double interestRate;
	@Column(name = "term-Months",unique = true, nullable = false)
	private Integer termMonths;
	@Column(name = "start-date",unique = true, nullable = false)
	private LocalDate startDate;
	@Column(name="maturity-date", unique = true,nullable = false)
	private LocalDate maturitydate;
	@Column(name = "status", nullable = false)
	private String status;
	@ManyToOne
	@JoinColumn(name = "customer_id", nullable = false)
	private Customer customer;
	@OneToMany(mappedBy = "loan", cascade = CascadeType.ALL)
	private List<LoanPayment>payments;
	public Loan() {
	}
 
	public Loan(Long loanId, String loanNumber, String loanType, Double principalAmount, Double interestRate,
			Integer termMonths, LocalDate startDate, LocalDate maturitydate, String status, Customer customer,
			List<LoanPayment> payments) {
		this.loanId = loanId;
		this.loanNumber = loanNumber;
		this.loanType = loanType;
		this.principalAmount = principalAmount;
		this.interestRate = interestRate;
		this.termMonths = termMonths;
		this.startDate = startDate;
		this.maturitydate = maturitydate;
		this.status = status;
		this.customer = customer;
		this.payments = payments;
	}
 
	public Long getLoanId() {
		return loanId;
	}
 
	public void setLoanId(Long loanId) {
		this.loanId = loanId;
	}
 
	public String getLoanNumber() {
		return loanNumber;
	}
 
	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}
 
	public String getLoanType() {
		return loanType;
	}
 
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
 
	public Double getPrincipalAmount() {
		return principalAmount;
	}
 
	public void setPrincipalAmount(Double principalAmount) {
		this.principalAmount = principalAmount;
	}
 
	public Double getInterestRate() {
		return interestRate;
	}
 
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}
 
	public Integer getTermMonths() {
		return termMonths;
	}
 
	public void setTermMonths(Integer termMonths) {
		this.termMonths = termMonths;
	}
 
	public LocalDate getStartDate() {
		return startDate;
	}
 
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
 
	public LocalDate getMaturitydate() {
		return maturitydate;
	}
 
	public void setMaturitydate(LocalDate maturitydate) {
		this.maturitydate = maturitydate;
	}
 
	public String getStatus() {
		return status;
	}
 
	public void setStatus(String status) {
		this.status = status;
	}
 
	public Customer getCustomer() {
		return customer;
	}
 
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
 
	public List<LoanPayment> getPayments() {
		return payments;
	}
 
	public void setPayments(List<LoanPayment> payments) {
		this.payments = payments;
	}
 
	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanNumber=" + loanNumber + ", loanType=" + loanType + ", principalAmount="
				+ principalAmount + ", interestRate=" + interestRate + ", termMonths=" + termMonths + ", startDate="
				+ startDate + ", maturitydate=" + maturitydate + ", status=" + status + ", payments=" + payments + "]";
	}



 
	


 
}