package Model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
 
@Entity
@Table(name = "card")
public class Card {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "card_id")
    private Long cardId;
 
    // FK → Customer(customer_id)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
 
    // FK → Account(account_id)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
 
    @Column(name = "card_number", nullable = false, unique = true, length = 25)
    private String cardNumber;  // tokenized PAN
 
    @Enumerated(EnumType.STRING)
    @Column(name = "card_type", nullable = false)
    private String cardType;  // Debit, Credit
 
    @Enumerated(EnumType.STRING)
    @Column(name = "network", nullable = false)
    private String network; // Visa, Mastercard, RuPay, Amex
 
    @Column(name = "expiry_month", nullable = false)
    private Integer expiryMonth;
 
    @Column(name = "expiry_year", nullable = false)
    private Integer expiryYear;
 
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private String status;  // ACTIVE, BLOCKED, EXPIRED, etc.
 
    @Column(name = "issued_at", nullable = false)
    private LocalDateTime issuedAt;
 
    public Card() {}
 
    public Long getCardId() {
        return cardId;
    }
 
    public void setCardId(Long cardId) {
        this.cardId = cardId;
    }
 
    public Customer getCustomer() {
        return customer;
    }
 
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
 
    public Account getAccount() {
        return account;
    }
 
    public void setAccount(Account account) {
        this.account = account;
    }
 
    public String getCardNumber() {
        return cardNumber;
    }
 
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
 
    public String getCardType() {
        return cardType;
    }
 
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }
 
    public String getNetwork() {
        return network;
    }
 
    public void setNetwork(String network) {
        this.network = network;
    }
 
    public Integer getExpiryMonth() {
        return expiryMonth;
    }
 
    public void setExpiryMonth(Integer expiryMonth) {
        this.expiryMonth = expiryMonth;
    }
 
    public Integer getExpiryYear() {
        return expiryYear;
    }
 
    public void setExpiryYear(Integer expiryYear) {
        this.expiryYear = expiryYear;
    }
 
    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
 
    public LocalDateTime getIssuedAt() {
        return issuedAt;
    }
 
    public void setIssuedAt(LocalDateTime issuedAt) {
        this.issuedAt = issuedAt;
    }
}