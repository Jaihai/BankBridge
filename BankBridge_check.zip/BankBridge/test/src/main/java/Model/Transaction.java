package Model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Transaction {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transaction_id;
	@ManyToOne
	@JoinColumn(name = "account_id")
	private Account account_id;
	@Column(name = "txn_type")
	private String txn_type;
	@Column(name = "amount")
	private Double amount;
	@Column(name = "currency")
	private String currency; //need to change the type
	@Column(name = "posted_at")
	private LocalDate posted_at;
	@Column(name = "reference")
	private String reference;
	@Column(name = "description")
	private String description;
	@Column(name = "balance_after")
	private Double balance_after;
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	protected Transaction(Integer transaction_id, Account account_id, String txn_type, Double amount, String currency,
			LocalDate posted_at, String reference, String description, Double balance_after) {
		this.transaction_id = transaction_id;
		this.account_id = account_id;
		this.txn_type = txn_type;
		this.amount = amount;
		this.currency = currency;
		this.posted_at = posted_at;
		this.reference = reference;
		this.description = description;
		this.balance_after = balance_after;
	}
	public Integer getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(Integer transaction_id) {
		this.transaction_id = transaction_id;
	}
	public Account getAccount_id() {
		return account_id;
	}
	public void setAccount_id(Account account_id) {
		this.account_id = account_id;
	}
	public String getTxn_type() {
		return txn_type;
	}
	public void setTxn_type(String txn_type) {
		this.txn_type = txn_type;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public LocalDate getPosted_at() {
		return posted_at;
	}
	public void setPosted_at(LocalDate posted_at) {
		this.posted_at = posted_at;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getBalance_after() {
		return balance_after;
	}
	public void setBalance_after(Double balance_after) {
		this.balance_after = balance_after;
	}
	
}
