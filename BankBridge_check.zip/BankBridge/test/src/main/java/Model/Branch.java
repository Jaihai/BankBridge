package Model;


import java.util.List;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="branch")
public class Branch {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="branch_id")
	private Long branchId;
	
	@Column(name="name",nullable=false)
	private String name;
	@Column(name="ifsc_code",nullable=false)
	private String ifscCode;
	@Column(name="address",nullable=false)
	private String address;
	@Column(name="city",nullable=false)
	private String city;
	@Column(name="state",nullable=false)
	private String state;
	@Column(name="postal_code",nullable=false)
	private String postalCode;
	@Column(name="country",nullable=false)
	private String country;
	@Column(name="phone",nullable=false)
	private String phone;
	
	@OneToMany(mappedBy="branch,cascade=CascadeType.ALL,fetch=FetchType.LAZY")
	private List<Account>account;
	
	public Branch() {
		
	}
 
	public Branch(Long branchId, String name, String ifscCode, String address, String city, String state,
			String postalCode, String country, String phone) {
		super();
		this.branchId = branchId;
		this.name = name;
		this.ifscCode = ifscCode;
		this.address = address;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.country = country;
		this.phone = phone;
		
	}
 
	public Long getBranchId() {
		return branchId;
	}
 
	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public String getIfscCode() {
		return ifscCode;
	}
 
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
 
	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}
 
	public String getCity() {
		return city;
	}
 
	public void setCity(String city) {
		this.city = city;
	}
 
	public String getState() {
		return state;
	}
 
	public void setState(String state) {
		this.state = state;
	}
 
	public String getPostalCode() {
		return postalCode;
	}
 
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
 
	public String getCountry() {
		return country;
	}
 
	public void setCountry(String country) {
		this.country = country;
	}
 
	public String getPhone() {
		return phone;
	}
 
	public void setPhone(String phone) {
		this.phone = phone;
	}
 
	@Override
	public String toString() {
		return "Branch [branchId=" + branchId + ", name=" + name + ", ifscCode=" + ifscCode + ", address=" + address
				+ ", city=" + city + ", state=" + state + ", postalCode=" + postalCode + ", country=" + country
				+ ", phone=" + phone + "]";
	}
	
	
	
}
 