package Model;
 
import java.math.BigDecimal;
import java.time.LocalDateTime;
 
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
 
@Entity

@Table(name="transfer")
 
public class Transfer
{
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Long transfer_id;
	 private Integer from_account_id;
	 private Integer to_account_id;
	 private BigDecimal amount;
	 private String curreny;
	 private LocalDateTime initiated_at;
	 private LocalDateTime completed_at;
	 private String status;
	 private String reference;
	
	 
	 public Transfer(Long transfer_id, Integer from_account_id, Integer to_account_id, BigDecimal amount, String curreny,
			LocalDateTime initiated_at, LocalDateTime completed_at, String status, String reference) {
		super();
		this.transfer_id = transfer_id;
		this.from_account_id = from_account_id;
		this.to_account_id = to_account_id;
		this.amount = amount;
		this.curreny = curreny;
		this.initiated_at = initiated_at;
		this.completed_at = completed_at;
		this.status = status;
		this.reference = reference;
	}
	 
	 
	 @Override
	public String toString() {
		return "Transfer [transfer_id=" + transfer_id + ", from_account_id=" + from_account_id + ", to_account_id="
				+ to_account_id + ", amount=" + amount + ", curreny=" + curreny + ", initiated_at=" + initiated_at
				+ ", completed_at=" + completed_at + ", status=" + status + ", reference=" + reference + "]";
	}
	 
	 

	    @ManyToOne(optional = false, fetch = FetchType.LAZY)
	    @JoinColumn(name = "from_account_id", nullable = false)
	    private Account fromAccount;

	    @ManyToOne(optional = false, fetch = FetchType.LAZY)
	    @JoinColumn(name = "to_account_id", nullable = false)

	    
	    //Getter and Setter
	 public Long getTransfer_id() {
		return transfer_id;
	}
	 public void setTransfer_id(Long transfer_id) {
		 this.transfer_id = transfer_id;
	 }
	 public Integer getFrom_account_id() {
		 return from_account_id;
	 }
	 public void setFrom_account_id(Integer from_account_id) {
		 this.from_account_id = from_account_id;
	 }
	 public Integer getTo_account_id() {
		 return to_account_id;
	 }
	 public void setTo_account_id(Integer to_account_id) {
		 this.to_account_id = to_account_id;
	 }
	 public BigDecimal getAmount() {
		 return amount;
	 }
	 public void setAmount(BigDecimal amount) {
		 this.amount = amount;
	 }
	 public String getCurreny() {
		 return curreny;
	 }
	 public void setCurreny(String curreny) {
		 this.curreny = curreny;
	 }
	 public LocalDateTime getInitiated_at() {
		 return initiated_at;
	 }
	 public void setInitiated_at(LocalDateTime initiated_at) {
		 this.initiated_at = initiated_at;
	 }
	 public LocalDateTime getCompleted_at() {
		 return completed_at;
	 }
	 public void setCompleted_at(LocalDateTime completed_at) {
		 this.completed_at = completed_at;
	 }
	 public String getStatus() {
		 return status;
	 }
	 public void setStatus(String status) {
		 this.status = status;
	 }
	 public String getReference() {
		 return reference;
	 }
	 public void setReference(String reference) {
		 this.reference = reference;
	 }

	
	
}