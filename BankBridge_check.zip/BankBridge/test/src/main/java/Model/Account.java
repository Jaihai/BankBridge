package Model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Account {
	

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long account_id;
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customer_id;
	@ManyToOne
	@JoinColumn(name = "branch_id")
	private Branch branch_id;
	@Column(name = "account_number")
	private Integer account_number;
	@Column(name = "account_type")
	private String account_type;
	private String currency; //need to change the type
	@Column(name = "balance")
	private Double balance;
	@Column(name = "status")
	private String status;
	@Column(name = "opened_at")
	private LocalDate opened_at;
	@Column(name = "closed_at")
	private LocalDate closed_at;
	
	public Account(Long account_id, Customer customer_id, Branch branch_id, Integer account_number,
			String account_type, String currency, Double balance, String status, LocalDate opened_at,
			LocalDate closed_at) {
		this.account_id = account_id;
		this.customer_id = customer_id;
		this.branch_id = branch_id;
		this.account_number = account_number;
		this.account_type = account_type;
		this.currency = currency;
		this.balance = balance;
		this.status = status;
		this.opened_at = opened_at;
		this.closed_at = closed_at;
	}
	public Long getAccount_id() {
		return account_id;
	}

	public void setAccount_id(Long account_id) {
		this.account_id = account_id;
	}

	public Customer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Customer customer_id) {
		this.customer_id = customer_id;
	}

	public Branch getBranch_id() {
		return branch_id;
	}

	public void setBranch_id(Branch branch_id) {
		this.branch_id = branch_id;
	}

	public Integer getAccount_number() {
		return account_number;
	}

	public void setAccount_number(Integer account_number) {
		this.account_number = account_number;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getOpened_at() {
		return opened_at;
	}

	public void setOpened_at(LocalDate opened_at) {
		this.opened_at = opened_at;
	}

	public LocalDate getClosed_at() {
		return closed_at;
	}

	public void setClosed_at(LocalDate closed_at) {
		this.closed_at = closed_at;
	}
	
}
