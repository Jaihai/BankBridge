package Model;
 
import jakarta.persistence.*;
import java.time.LocalDateTime;
 
@Entity
@Table(name = "payee")
public class Payee {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payee_id")
    private Long payeeId;
 
    // FK → Customer
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
 
    @Column(name = "payee_name", nullable = false, length = 100)
    private String payeeName;
 
    @Column(name = "payee_account_number", nullable = false, length = 30)
    private String payeeAccountNumber;
 
    @Column(name = "payee_bank_name", nullable = false, length = 100)
    private String payeeBankName;
 
    @Column(name = "payee_ifsc_routing_number", nullable = false, length = 20)
    private String payeeIfscRoutingNumber;
 
    @Column(name = "nickname", length = 50)
    private String nickname;
 
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
 
    @Column(name = "status", nullable = false, length = 20)
    private String status; // e.g. ACTIVE, INACTIVE, BLOCKED
 
    /* Constructors */
    public Payee() {}
 
    /* Lifecycle hooks */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
 
    /* Getters and Setters */
    public Long getPayeeId() {
        return payeeId;
    }
 
    public Customer getCustomer() {
        return customer;
    }
 
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
 
    public String getPayeeName() {
        return payeeName;
    }
 
    public void setPayeeName(String payeeName) {
        this.payeeName = payeeName;
    }
 
    public String getPayeeAccountNumber() {
        return payeeAccountNumber;
    }
 
    public void setPayeeAccountNumber(String payeeAccountNumber) {
        this.payeeAccountNumber = payeeAccountNumber;
    }
 
    public String getPayeeBankName() {
        return payeeBankName;
    }
 
    public void setPayeeBankName(String payeeBankName) {
        this.payeeBankName = payeeBankName;
    }
 
    public String getPayeeIfscRoutingNumber() {
        return payeeIfscRoutingNumber;
    }
 
    public void setPayeeIfscRoutingNumber(String payeeIfscRoutingNumber) {
        this.payeeIfscRoutingNumber = payeeIfscRoutingNumber;
    }
 
    public String getNickname() {
        return nickname;
    }
 
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
 
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
 
    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
}