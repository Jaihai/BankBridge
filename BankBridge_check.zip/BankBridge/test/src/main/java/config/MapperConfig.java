package config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import Mapper.AccountMapper;
import Mapper.AddressMapper;
import Mapper.TransactionMapper;

@Configuration
public class MapperConfig {

 @Bean public AccountMapper accountMapper() { return new AccountMapper(); }
 @Bean public AddressMapper addressMapper() { return new AddressMapper(); }
 @Bean public TransactionMapper transactionMapper() { return new TransactionMapper(); }
}