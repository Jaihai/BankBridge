package Model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transaction_id;

    private String txn_type;
    private BigDecimal amount;
    private String currency;
    private LocalDateTime posted_at;
    private String reference;
    private String description;
    private BigDecimal balance_after;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id")
    private Account account;

    public Transaction() {}

    public Long getTransaction_id() { return transaction_id; }
    public void setTransaction_id(Long transaction_id) { this.transaction_id = transaction_id; }
    public String getTxn_type() { return txn_type; }
    public void setTxn_type(String txn_type) { this.txn_type = txn_type; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public LocalDateTime getPosted_at() { return posted_at; }
    public void setPosted_at(LocalDateTime posted_at) { this.posted_at = posted_at; }
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getBalance_after() { return balance_after; }
    public void setBalance_after(BigDecimal balance_after) { this.balance_after = balance_after; }
    public Account getAccount() { return account; }
    public void setAccount(Account account) { this.account = account; }
}
