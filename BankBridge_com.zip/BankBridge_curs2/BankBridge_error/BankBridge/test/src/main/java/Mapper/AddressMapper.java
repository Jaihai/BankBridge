package Mapper;

import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import Model.Customer;

import java.util.ArrayList;
import java.util.List;

public class AddressMapper {

    public AddressDto toDto(Customer c) {
        if (c == null) return null;
        Long customerId = c.getCustomerId();
        return new AddressDto(
                null,
                customerId,
                c.getAddress_line(),
                c.getCity(),
                c.getState(),
                c.getPostal_code(),
                c.getCountry()
        );
    }

    public List<AddressDto> toDtoList(List<Customer> customers) {
        if (customers == null || customers.isEmpty()) return new ArrayList<>();
        List<AddressDto> out = new ArrayList<>(customers.size());
        for (Customer c : customers) {
            out.add(toDto(c));
        }
        return out;
    }

    public void applyCreate(CreateAddressDto dto, Customer customer) {
        if (dto == null || customer == null) return;
        customer.setAddress_line(dto.getAddressLine());
        customer.setCity(dto.getCity());
        customer.setState(dto.getState());
        customer.setPostal_code(dto.getPostalCode());
        customer.setCountry(dto.getCountry());
    }

    public void applyUpdate(UpdateAddressDto dto, Customer customer) {
        if (dto == null || customer == null) return;
        customer.setAddress_line(dto.getAddressLine());
        customer.setCity(dto.getCity());
        customer.setState(dto.getState());
        customer.setPostal_code(dto.getPostalCode());
        customer.setCountry(dto.getCountry());
    }
}
