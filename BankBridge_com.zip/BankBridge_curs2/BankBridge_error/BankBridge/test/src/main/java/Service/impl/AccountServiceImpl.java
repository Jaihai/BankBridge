package Service.impl;

import Mapper.AccountMapper;
import Model.Account;
import Model.Branch;
import Model.Customer;
import Repository.AccountRepository;
import Repository.BranchRepository;
import Repository.CustomerRepository;
import Service.AccountService;
import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import exception.AccountCloseException;
import exception.AccountNotFoundException;
import exception.CustomerIDNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepo;
    private final CustomerRepository customerRepo;
    private final BranchRepository branchRepo;
    private final AccountMapper mapper;

    public AccountServiceImpl(AccountRepository accountRepo,
                              CustomerRepository customerRepo,
                              BranchRepository branchRepo,
                              AccountMapper mapper) {
        this.accountRepo = accountRepo;
        this.customerRepo = customerRepo;
        this.branchRepo = branchRepo;
        this.mapper = mapper;
    }

    @Override
    public Long create(CreateAccountDto dto) {
        Customer customer = customerRepo.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));
        Branch branch = branchRepo.findById(dto.getBranchId())
                .orElseThrow(() -> new RuntimeException("Branch not found: " + dto.getBranchId()));
        String accountNumber = "ACC" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        Account entity = mapper.fromCreate(dto, customer, branch, accountNumber);
        return accountRepo.save(entity).getAccount_id();
    }

    @Override
    public void update(Long id, UpdateAccountDto dto) {
        Account entity = accountRepo.findById(id)
                .orElseThrow(() -> new AccountNotFoundException(id));
        mapper.applyUpdate(dto, entity);
        accountRepo.save(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public AccountDto get(Long id) {
    return accountRepo.findById(id)
            .map(mapper::toDto)
            .orElseThrow(() -> new AccountNotFoundException(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> listAll() {
        return mapper.toDtoList(accountRepo.findAll());
    }

    @Override
    public void delete(Long id) {
        Account entity = accountRepo.findById(id)
                .orElseThrow(() -> new AccountNotFoundException(id));
        BigDecimal balance = entity.getBalance();
        if (balance != null && balance.compareTo(BigDecimal.ZERO) != 0) {
            throw new AccountCloseException();
        }
        accountRepo.deleteById(id);
    }
}
