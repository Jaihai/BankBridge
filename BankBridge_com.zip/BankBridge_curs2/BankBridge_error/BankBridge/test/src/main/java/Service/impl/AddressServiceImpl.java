package Service.impl;

import Service.AddressService;
import Mapper.AddressMapper;
import Model.Customer;
import Repository.CustomerRepository;
import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import exception.AddressDetailsNotFoundException;
import exception.CustomerIDNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AddressServiceImpl implements AddressService {

    private final CustomerRepository customerRepo;
    private final AddressMapper addressMapper;

    public AddressServiceImpl(CustomerRepository customerRepo, AddressMapper addressMapper) {
        this.customerRepo = customerRepo;
        this.addressMapper = addressMapper;
    }

    @Override
    public Long create(CreateAddressDto dto) {
        Customer c = customerRepo.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));
        addressMapper.applyCreate(dto, c);
        customerRepo.save(c);
        return c.getCustomerId();
    }

    @Override
    public void updateByCustomerId(Long customerId, UpdateAddressDto dto) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        addressMapper.applyUpdate(dto, c);
        customerRepo.save(c);
    }

    @Override
    public void deleteByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        c.setAddress_line(null);
        c.setCity(null);
        c.setState(null);
        c.setPostal_code(null);
        c.setCountry(null);
        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AddressDto> listAll() {
        return customerRepo.findAll().stream()
                .filter(c -> c.getAddress_line() != null || c.getCity() != null || c.getCountry() != null)
                .map(addressMapper::toDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        if (c.getAddress_line() == null && c.getCity() == null && c.getState() == null
                && c.getPostal_code() == null && c.getCountry() == null) {
            throw new AddressDetailsNotFoundException(customerId);
        }
        return addressMapper.toDto(c);
    }
}
