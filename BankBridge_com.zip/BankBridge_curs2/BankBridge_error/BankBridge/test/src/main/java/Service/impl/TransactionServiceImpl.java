package Service.impl;

import Mapper.TransactionMapper;
import Model.Account;
import Model.Transaction;
import Repository.AccountRepository;
import Repository.TransactionRepository;
import Service.TransactionService;
import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;
import exception.AccountNotFoundException;
import exception.InSufficientBalanceException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepo;
    private final TransactionRepository txnRepo;
    private final TransactionMapper mapper;

    public TransactionServiceImpl(AccountRepository accountRepo,
                                  TransactionRepository txnRepo,
                                  TransactionMapper mapper) {
        this.accountRepo = accountRepo;
        this.txnRepo = txnRepo;
        this.mapper = mapper;
    }

    @Override
    public String deposit(DepositRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getAccountNumber()));

        BigDecimal current = a.getBalance() != null ? a.getBalance() : BigDecimal.ZERO;
        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        BigDecimal newBal = current.add(amount);
        a.setBalance(newBal);

        Transaction t = mapper.creditFromDeposit(a, req);
        t.setBalance_after(newBal);
        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Created Successfully";
    }

    @Override
    public String withdraw(WithdrawRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getAccountNumber()));

        BigDecimal current = a.getBalance() != null ? a.getBalance() : BigDecimal.ZERO;
        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        if (current.compareTo(amount) < 0) {
            throw new InSufficientBalanceException();
        }

        BigDecimal newBal = current.subtract(amount);
        a.setBalance(newBal);

        Transaction t = mapper.debitFromWithdraw(a, req);
        t.setBalance_after(newBal);
        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Modified Successfully";
    }

    @Override
    public String fundTransfer(FundTransferRequest req) {
        Account from = accountRepo.findByAccountNumber(req.getFromAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getFromAccountNumber()));
        Account to = accountRepo.findByAccountNumber(req.getToAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getToAccountNumber()));

        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        BigDecimal fromBal = from.getBalance() != null ? from.getBalance() : BigDecimal.ZERO;
        if (fromBal.compareTo(amount) < 0) {
            throw new InSufficientBalanceException();
        }

        from.setBalance(fromBal.subtract(amount));
        Transaction debit = mapper.debitFromTransfer(from, req);
        debit.setBalance_after(from.getBalance());

        BigDecimal toBal = to.getBalance() != null ? to.getBalance() : BigDecimal.ZERO;
        BigDecimal newToBal = toBal.add(amount);
        to.setBalance(newToBal);
        Transaction credit = mapper.creditFromTransfer(to, req);
        credit.setBalance_after(newToBal);

        txnRepo.save(debit);
        txnRepo.save(credit);
        accountRepo.save(from);
        accountRepo.save(to);

        return "Record Modified Successfully";
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> summary(LocalDateTime from, LocalDateTime to) {
        return mapper.toDtoList(txnRepo.findAllBetween(from, to));
    }
}
