package dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public class DepositRequest {
    @NotBlank
    private String accountNumber;
    @NotNull @Positive
    private Double amount;

    public DepositRequest() { }

    public DepositRequest(String accountNumber, @NotNull @Positive Double amount) {
        this.accountNumber = accountNumber;
        this.amount = amount;
    }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public Double getAmount() { return amount; }
    public void setAmount(@NotNull @Positive Double amount) { this.amount = amount; }
}