# Bank Bridge Application

Spring Boot REST API for retail banking covering Customers, Accounts, Addresses, Transactions (Deposit, Withdraw, Fund Transfer).

## Requirements Met

- **Spring Boot + JPA** – REST API with PostgreSQL
- **Docker** – Containerized app + PostgreSQL
- **Custom Exceptions** – CustomerIDNotFoundException, InvalidLoginException, CustomerDBEmptyException, AddressDetailsNotFoundException, InSufficientBalanceException

## API Endpoints

### Customer (`/bankapi/v1/customer`)
| Method | Path | Description |
|--------|------|-------------|
| POST | / | Add new customer |
| PUT | /?id= | Modify customer |
| GET | / | List all customers |
| GET | /{id} | Get customer by id |
| DELETE | /{id} | Delete customer |
| POST | /login | Login (email + password) |
| GET | /getAllAccounts/{id} | Accounts owned by customer |
| GET | /findAddress/{id} | Address for customer |

### Address (`/bankapi/v1/address`)
| Method | Path | Description |
|--------|------|-------------|
| POST | / | Add address (on customer) |
| PUT | /?customerId= | Modify address |
| GET | / | List all addresses |
| GET | /{customerid} | Get address by customer id |
| DELETE | /{id} | Delete address |

### Account (`/bankapi/v1/account`)
| Method | Path | Description |
|--------|------|-------------|
| POST | / | Open account (requires customerId, branchId) |
| PUT | /?id= | Modify account |
| GET | / | List all accounts |
| GET | /{id} | Get account by id |
| DELETE | /{id} | Close account (fails if balance ≠ 0) |

### Transaction (`/bankapi/v1/transaction`)
| Method | Path | Description |
|--------|------|-------------|
| POST | /deposit | Deposit (accountNumber, amount) |
| POST | /withdraw | Withdraw (accountNumber, amount) |
| POST | /fundtransfer | Transfer (fromAccountNumber, toAccountNumber, amount) |
| GET | /summary?from=&to= | Transaction summary by date range |

## Project Structure

```
src/main/java/
├── com.example.bankbridgeapp/
│   └── BankBridgeAppApplication.java
├── Controller/
│   ├── AccountController.java
│   ├── AddressController.java
│   ├── CustomerController.java
│   └── TransactionController.java
├── Service/
│   ├── AccountService.java
│   ├── AddressService.java
│   ├── CustomerService.java
│   ├── TransactionService.java
│   └── impl/
│       ├── AccountServiceImpl.java
│       ├── AddressServiceImpl.java
│       ├── CustomerServiceImpl.java
│       └── TransactionServiceImpl.java
├── Model/
│   ├── Account.java, Branch.java, Card.java, Customer.java
│   ├── Loan.java, LoanPayment.java, Payee.java
│   ├── Transaction.java, Transfer.java, User.java
├── Repository/
│   ├── AccountRepository.java, BranchRepository.java, ...
├── Mapper/
│   ├── AccountMapper.java, AddressMapper.java
│   ├── CustomerMapper.java, TransactionMapper.java
├── dto/
│   ├── CreateCustomerDto, CustomerDto, LoginRequestDto, ...
├── exception/
│   ├── CustomerIDNotFoundException.java
│   ├── InvalidLoginException.java
│   ├── CustomerDBEmptyException.java
│   ├── AddressDetailsNotFoundException.java
│   └── InSufficientBalanceException.java
├── ExceptionHandler/
│   └── GlobalExceptionHandler.java
└── config/
    ├── SecurityConfig.java
    ├── SecurityBeans.java
    └── MapperConfig.java

src/main/resources/
├── application.properties
├── data.sql          # Seeds default branch
└── schema.sql        # Reference DDL
```

## Run Locally

1. **PostgreSQL** – Create DB `bankdb`:

   ```bash
   createdb bankdb
   ```

2. **Update** `application.properties` if needed (URL, user, password).

3. **Run**:
   ```bash
   ./mvnw spring-boot:run
   ```

## Run with Docker

```bash
docker-compose up -d
```

- App: http://localhost:8080
- Swagger UI: http://localhost:8080/swagger-ui.html

## Quick Test (cURL)

```bash
# Create customer
curl -X POST http://localhost:8080/bankapi/v1/customer \
  -H "Content-Type: application/json" \
  -d '{"firstName":"John","lastName":"Doe","email":"john@test.com","password":"pass123"}'

# Create branch first (use DB or add BranchController), then create account
curl -X POST http://localhost:8080/bankapi/v1/account \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"branchId":1,"accountType":"Savings","currency":"INR","initialDeposit":1000}'
```
