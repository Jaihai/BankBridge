package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.Payee;

public interface PayeeRepository extends JpaRepository <Payee,Long> {

}
