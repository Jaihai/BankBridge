package Account_Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import Model.Account;
import Model.Branch;
import Model.Customer;
import Repository.AccountRepository;
import Repository.BranchRepository;
import Repository.CustomerRepository;
import Service.impl.AccountServiceImpl;
import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import exception.AccountCloseException;
import exception.AccountNotFoundException;
import exception.CustomerIDNotFoundException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Unit tests for AccountServiceImpl using Mockito stubs.
 * Covers pass and fail flows for create/update/get/list/delete.
 */
@ExtendWith(MockitoExtension.class)
public class Account_Junit_Mock {

    @InjectMocks
    private AccountServiceImpl accountService;

    @Mock private AccountRepository accountRepo;
    @Mock private CustomerRepository customerRepo;
    @Mock private BranchRepository branchRepo;

    private Customer customer;
    private Branch branch;
    private Account account;

    @BeforeEach
    void setup() {
        // Arrange common fixtures used by multiple tests
        customer = new Customer();
        customer.setCustomer_id(10L);

        branch = new Branch();

        account = new Account();
        account.setAccount_id(1001L);
        account.setCustomer(customer);
        account.setBranch(branch);
        account.setAccount_number("ACC123456789");
        account.setAccount_type("SAVINGS");
        account.setCurrency("INR");
        account.setBalance(new BigDecimal("5000"));
        account.setStatus("OPEN");
        account.setOpened_at(LocalDateTime.now());
    }

    // ---------------- PASS TESTCASES ----------------

    /**  create_success: Should create account when customer & branch exist and save returns id. */
    @Test
    void create_success() {
        // Arrange
        CreateAccountDto dto = new CreateAccountDto();
        dto.setCustomerId(10L);
        dto.setBranchId(2L);
        dto.setAccountType("SAVINGS");
        dto.setCurrency("INR");
        dto.setInitialDeposit(new BigDecimal("1000"));

        when(customerRepo.findById(10L)).thenReturn(Optional.of(customer));
        when(branchRepo.findById(2L)).thenReturn(Optional.of(branch));
        when(accountRepo.save(any(Account.class))).thenReturn(account);

        // Act
        Long id = accountService.create(dto);

        // Assert
        assertEquals(1001L, id);
        verify(accountRepo).save(any(Account.class));
    }

    /**  update_success: Should update account type/status when account exists. */
    @Test
    void update_success() {
        // Arrange
        UpdateAccountDto dto = new UpdateAccountDto();
        dto.setAccountType("CURRENT");
        dto.setStatus("OPEN");
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));

        // Act
        accountService.update(1001L, dto);

        // Assert
        assertEquals("CURRENT", account.getAccount_type());
        verify(accountRepo).save(account);
    }

    /**  get_success: Should map Account entity to AccountDto when found. */
    @Test
    void get_success() {
        // Arrange
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));

        // Act
        AccountDto dto = accountService.get(1001L);

        // Assert
        assertEquals(1001L, dto.getId());
        assertEquals("SAVINGS", dto.getAccountType());
    }

    /**  listAll_success: Should return a list of mapped AccountDto objects. */
    @Test
    void listAll_success() {
        // Arrange
        when(accountRepo.findAll()).thenReturn(List.of(account));

        // Act
        List<AccountDto> list = accountService.listAll();

        // Assert
        assertEquals(1, list.size());
        assertEquals(1001L, list.get(0).getId());
    }

    /** delete_success_whenZeroBalance: Should delete when balance is ZERO. */
    @Test
    void delete_success_whenZeroBalance() {
        // Arrange: zero balance -> allowed to close
        Account zeroBal = new Account();
        zeroBal.setAccount_id(20L);
        zeroBal.setBalance(BigDecimal.ZERO);
        when(accountRepo.findById(20L)).thenReturn(Optional.of(zeroBal));

        // Act
        accountService.delete(20L);

        // Assert
        verify(accountRepo).deleteById(20L);
    }

    // ---------------- FAILURE TESTCASES ----------------

    /**  create_fail_customerNotFound: Should throw when customer doesn't exist. */
    @Test
    void create_fail_customerNotFound() {
        // Arrange
        CreateAccountDto dto = new CreateAccountDto();
        dto.setCustomerId(999L);
        dto.setBranchId(1L);
        when(customerRepo.findById(999L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThrows(CustomerIDNotFoundException.class,
                () -> accountService.create(dto));
    }

    /**  create_fail_branchNotFound: Should throw when branch doesn't exist. */
    @Test
    void create_fail_branchNotFound() {
        // Arrange
        CreateAccountDto dto = new CreateAccountDto();
        dto.setCustomerId(10L);
        dto.setBranchId(777L);
        when(customerRepo.findById(10L)).thenReturn(Optional.of(customer));
        when(branchRepo.findById(777L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThrows(RuntimeException.class,
                () -> accountService.create(dto));
    }

    /**  update_fail_accountNotFound: Should throw when account id not present. */
    @Test
    void update_fail_accountNotFound() {
        // Arrange
        when(accountRepo.findById(1234L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThrows(AccountNotFoundException.class,
                () -> accountService.update(1234L, new UpdateAccountDto()));
    }

    /**  get_fail_notFound: Should throw when account is missing. */
    @Test
    void get_fail_notFound() {
        // Arrange
        when(accountRepo.findById(404L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThrows(AccountNotFoundException.class,
                () -> accountService.get(404L));
    }

    /** delete_fail_nonZeroBalance: Should throw AccountCloseException when balance != ZERO. */
    @Test
    void delete_fail_nonZeroBalance() {
        // Arrange: existing account with non-zero balance
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account)); // balance = 5000

        // Act + Assert
        assertThrows(AccountCloseException.class,
                () -> accountService.delete(1001L));
        verify(accountRepo, never()).deleteById(anyLong());
    }

    /**  delete_fail_notFound: Should throw when account id is missing. */
    @Test
    void delete_fail_notFound() {
        // Arrange
        when(accountRepo.findById(77L)).thenReturn(Optional.empty());

        // Act + Assert
        assertThrows(AccountNotFoundException.class,
                () -> accountService.delete(77L));
    }

    // ---------------- EXTRA HIGH-VALUE TESTS (added) ----------------

    /**  create_initialDepositNull_defaultsToZero: Should default balance to ZERO when initialDeposit is null. */
    @Test
    void create_initialDepositNull_defaultsToZero() {
        // Arrange
        CreateAccountDto dto = new CreateAccountDto();
        dto.setCustomerId(10L);
        dto.setBranchId(2L);
        dto.setAccountType("SAVINGS");
        dto.setCurrency("INR");
        dto.setInitialDeposit(null); // edge case

        when(customerRepo.findById(10L)).thenReturn(Optional.of(customer));
        when(branchRepo.findById(2L)).thenReturn(Optional.of(branch));

        when(accountRepo.save(any(Account.class))).thenAnswer(inv -> {
            Account a = inv.getArgument(0);
            a.setAccount_id(999L);
            return a;
        });

        // Act
        Long id = accountService.create(dto);

        // Assert
        assertEquals(999L, id);
        ArgumentCaptor<Account> cap = ArgumentCaptor.forClass(Account.class);
        verify(accountRepo).save(cap.capture());
        assertEquals(0, BigDecimal.ZERO.compareTo(cap.getValue().getBalance()), "balance should default to ZERO");
    }

    /**  create_fail_saveThrowsRuntime: Should bubble up repository save failure. */
    @Test
    void create_fail_saveThrowsRuntime() {
        // Arrange
        CreateAccountDto dto = new CreateAccountDto();
        dto.setCustomerId(10L);
        dto.setBranchId(2L);
        dto.setAccountType("SAVINGS");
        dto.setCurrency("INR");

        when(customerRepo.findById(10L)).thenReturn(Optional.of(customer));
        when(branchRepo.findById(2L)).thenReturn(Optional.of(branch));
        when(accountRepo.save(any(Account.class))).thenThrow(new RuntimeException("insert failed"));

        // Act + Assert
        RuntimeException ex = assertThrows(RuntimeException.class, () -> accountService.create(dto));
        assertTrue(ex.getMessage().contains("insert failed"));
    }

    /**  get_fail_repoThrowsRuntime: Should bubble up repository read failures. */
    @Test
    void get_fail_repoThrowsRuntime() {
        // Arrange
        when(accountRepo.findById(1L)).thenThrow(new RuntimeException("read failed"));

        // Act + Assert
        RuntimeException ex = assertThrows(RuntimeException.class, () -> accountService.get(1L));
        assertTrue(ex.getMessage().contains("read failed"));
    }

    /**  delete_fail_repoDeleteThrowsRuntime: Should bubble up repository delete failures. */
    @Test
    void delete_fail_repoDeleteThrowsRuntime() {
        // Arrange: ok to close (zero bal) but delete call fails
        Account zero = new Account();
        zero.setAccount_id(20L);
        zero.setBalance(BigDecimal.ZERO);
        when(accountRepo.findById(20L)).thenReturn(Optional.of(zero));
        doThrow(new RuntimeException("delete failed")).when(accountRepo).deleteById(20L);

        // Act + Assert
        RuntimeException ex = assertThrows(RuntimeException.class, () -> accountService.delete(20L));
        assertTrue(ex.getMessage().contains("delete failed"));
    }
}