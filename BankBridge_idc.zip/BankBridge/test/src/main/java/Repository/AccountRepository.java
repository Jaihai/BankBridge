package Repository;

import Model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    // OK to use account_number here because your Account field is named account_number
    @Query("SELECT a FROM Account a WHERE a.account_number = :accountNumber")
    Optional<Account> findByAccountNumber(@Param("accountNumber") String accountNumber);

    // ❌ WRONG before: a.customer.customer_id  (JPQL must use Java property names on Customer)
    // ✅ FIX: use a.customer.customerId (your Customer entity has 'customerId' property)
    @Query("SELECT a FROM Account a WHERE a.customer.customerId = :customerId")
    List<Account> findAllByCustomerId(@Param("customerId") Long customerId);

    // Alternatively (derived method, no @Query needed) – pick ONE approach:
    // List<Account> findAllByCustomer_CustomerId(Long customerId);
}