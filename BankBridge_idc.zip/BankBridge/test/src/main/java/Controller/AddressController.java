package Controller;
import Service.AddressService;
import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/address")
public class AddressController {

    private final AddressService addressService;

    public AddressController(AddressService addressService) { this.addressService = addressService; }

    // POST /bankapi/v1/address - Add new address (on a Customer)
    @PostMapping
    public ResponseEntity<String> create(@Valid @RequestBody CreateAddressDto dto) {
        addressService.create(dto); // Service updates the customer’s address fields
        return ResponseEntity.status(201).body("Record Created Successfully");
    }

    // PUT /bankapi/v1/address - Modify the address (on a Customer)
    // Pass ?customerId= in the query (or you can include in UpdateAddressDto if you prefer)
    @PutMapping
    public ResponseEntity<String> update(@RequestParam("customerId") Long customerId,
                                         @Valid @RequestBody UpdateAddressDto dto) {
        addressService.updateByCustomerId(customerId, dto); // add this method in your service if not present
        return ResponseEntity.ok("Record Modified Successfully");
    }

    // GET /bankapi/v1/address - List all addresses (projections from customers)
    @GetMapping
    public ResponseEntity<List<AddressDto>> listAll() {
        return ResponseEntity.ok(addressService.listAll());
    }

    // DELETE /bankapi/v1/address/{id} - Delete address by id (customer id - clears address fields)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        addressService.deleteByCustomerId(id);
        return ResponseEntity.noContent().build();
    }

    // GET /bankapi/v1/address/{customerid} - Search address by customerId
    @GetMapping("/{customerid}")
    public ResponseEntity<AddressDto> getByCustomer(@PathVariable("customerid") Long customerId) {
        return ResponseEntity.ok(addressService.findByCustomerId(customerId));
    }
}
