package exception;

public class AddressDetailsNotFoundException extends RuntimeException {
    public AddressDetailsNotFoundException(Long customerId) {
        super("Validation Failed" + customerId);
    }
}
