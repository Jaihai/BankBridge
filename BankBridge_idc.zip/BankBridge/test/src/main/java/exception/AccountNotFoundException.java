package exception;

public class AccountNotFoundException extends RuntimeException {
    public AccountNotFoundException(Long id) {
        super("Validation Failed " + id);
    }
    public AccountNotFoundException(String accountNumber) {
        super("Validation Failed " + accountNumber);
    }
}
