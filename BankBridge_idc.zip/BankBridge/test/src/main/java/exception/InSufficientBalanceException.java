package exception;

public class InSufficientBalanceException extends RuntimeException {
    public InSufficientBalanceException() {
        super("Validation Failed");
    }
    public InSufficientBalanceException(String message) {
        super(message);
    }
}
