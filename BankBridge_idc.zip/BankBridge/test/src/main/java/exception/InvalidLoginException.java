package exception;

public class InvalidLoginException extends RuntimeException {
    public InvalidLoginException() {
        super("Validation Failed");
    }
    public InvalidLoginException(String message) {
        super(message);
    }
}
