package exception;

public class CustomerIDNotFoundException extends RuntimeException {
    public CustomerIDNotFoundException(Long id) {
        super("Validation Failed" + id);
    }
}
