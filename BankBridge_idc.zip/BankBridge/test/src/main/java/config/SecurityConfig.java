package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder; // comes from SecurityBeans
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    // Reuse the existing PasswordEncoder bean from SecurityBeans
    @Bean
    public UserDetailsService users(PasswordEncoder encoder) {
        UserDetails admin = User.withUsername("user")
                .password(encoder.encode("user"))  // bcrypt at runtime
                .roles("USER")                         // add more roles as needed
                .build();

        return new InMemoryUserDetailsManager(admin);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Stateless API style (Swagger will still work with Basic Auth)
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth
                // Swagger & OpenAPI endpoints REQUIRE authentication
                .requestMatchers(
                    "/swagger-ui.html",
                    "/swagger-ui/**",
                    "/v3/api-docs/**",
                    "/swagger-ui/index.html"
                ).authenticated()

                // Your API endpoints: permit or secure as you need
                .requestMatchers("/bankapi/v1/**").permitAll()

                // Everything else permitted (adjust for your needs)
                .anyRequest().permitAll()
            )

            // Use HTTP Basic for Swagger auth
            .httpBasic(Customizer.withDefaults())

            // Disable form login (not needed for APIs)
            .formLogin(form -> form.disable())

            // Allow frames (optional; helpful for H2 Console if you ever use it)
            .headers(headers -> headers.frameOptions(frame -> frame.disable()));

        return http.build();
    }
}