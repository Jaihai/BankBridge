package Service;

import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;

import java.util.List;

public interface AddressService {
    Long create(CreateAddressDto dto);                 // returns customer id
    void updateByCustomerId(Long customerId, UpdateAddressDto dto);
    void deleteByCustomerId(Long customerId);         // clears address fields
    List<AddressDto> listAll();                       // projects all customers’ addresses
    AddressDto findByCustomerId(Long customerId);
}