package Service.impl;

import Service.CustomerService;
import Model.Account;
import Model.Customer;
import Repository.AccountRepository;
import Repository.CustomerRepository;
import dto.AccountDto;
import dto.AddressDto;
import dto.CreateCustomerDto;
import dto.CustomerDto;
import dto.LoginRequestDto;
import dto.LoginResponseDto;
import dto.UpdateCustomerDto;
import exception.AddressDetailsNotFoundException;
import exception.CustomerDBEmptyException;
import exception.CustomerIDNotFoundException;
import exception.InvalidLoginException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepo;
    private final AccountRepository accountRepo;
    private final PasswordEncoder passwordEncoder;

    public CustomerServiceImpl(CustomerRepository customerRepo,
                               AccountRepository accountRepo,
                               PasswordEncoder passwordEncoder) {
        this.customerRepo = customerRepo;
        this.accountRepo = accountRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Long create(CreateCustomerDto dto) {
        customerRepo.findByEmail(dto.getEmail()).ifPresent(x -> {
            throw new IllegalArgumentException("Email already exists");
        });

        Customer c = new Customer();

        // MANUAL IDs: keep this. If you switch to GENERATED IDs, remove it.
        c.setCustomerId(dto.getCustomerId());

        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setEmail(dto.getEmail());
        c.setDateOfBirth(dto.getDateOfBirth());
        // Ensure your Customer entity has setPasswordHash(...). If it's setPassword_hash(...), use that.
        c.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        c.setStatus("ACTIVE");
        c.setCreatedAt(LocalDateTime.now());

        Customer saved = customerRepo.save(c);
        return saved.getCustomerId();
    }

    @Override
    public void update(Long id, UpdateCustomerDto dto) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));

        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setPhone(dto.getPhone());

        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerDto> listAll() {
        List<Customer> customers = customerRepo.findAll();
        if (customers.isEmpty()) {
            throw new CustomerDBEmptyException();
        }
        return customers.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDto get(Long id) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));
        return toDto(c);
    }

    @Override
    public void delete(Long id) {
        customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));
        customerRepo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public LoginResponseDto login(LoginRequestDto dto) {
        Customer c = customerRepo.findByEmail(dto.getEmail())
                .orElseThrow(InvalidLoginException::new);

        boolean ok = passwordEncoder.matches(dto.getPassword(), c.getPasswordHash());
        if (!ok) throw new InvalidLoginException();

        return new LoginResponseDto(
                c.getCustomerId(),
                c.getFirstName(),
                c.getLastName(),
                c.getEmail()
        );
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> getAllAccounts(Long customerId) {
        customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));

        // Use the repository method you defined (with @Query above):
        List<Account> accounts = accountRepo.findAllByCustomerId(customerId);

        // If you chose the derived method version instead, use:
        // List<Account> accounts = accountRepo.findAllByCustomer_CustomerId(customerId);

        return accounts.stream()
                .map(this::toAccountDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findAddress(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));

        boolean addressMissing =
                c.getAddressLine() == null
                        && c.getCity() == null
                        && c.getState() == null
                        && c.getPostalCode() == null
                        && c.getCountry() == null;

        if (addressMissing) {
            throw new AddressDetailsNotFoundException(customerId);
        }

        AddressDto dto = new AddressDto();
        // dto.setId(c.getCustomer_id()); // optional
        dto.setCustomerId(c.getCustomerId());
        dto.setAddressLine(c.getAddressLine());
        dto.setCity(c.getCity());
        dto.setState(c.getState());
        dto.setPostalCode(c.getPostalCode());
        dto.setCountry(c.getCountry());
        return dto;
    }

    // -------- Mappers --------
    private CustomerDto toDto(Customer c) {
        CustomerDto dto = new CustomerDto();
        dto.setCustomerId(c.getCustomerId());
        dto.setFirstName(c.getFirstName());
        dto.setLastName(c.getLastName());
        dto.setEmail(c.getEmail());
        dto.setPhone(c.getPhone());
        dto.setStatus(c.getStatus());
        dto.setCreatedAt(c.getCreatedAt());
        dto.setDateOfBirth(c.getDateOfBirth());
        return dto;
    }

    private AccountDto toAccountDto(Account acc) {
        AccountDto dto = new AccountDto();
        // Using your Account entity's snake_case accessors
        dto.setId(acc.getAccount_id());
        dto.setCustomerId(acc.getCustomer() != null ? acc.getCustomer().getCustomerId() : null);
        dto.setAccountNumber(acc.getAccount_number());
        dto.setAccountType(acc.getAccount_type());
        dto.setCurrency(acc.getCurrency());
        dto.setBalance(acc.getBalance());
        dto.setStatus(acc.getStatus());
        return dto;
    }
}