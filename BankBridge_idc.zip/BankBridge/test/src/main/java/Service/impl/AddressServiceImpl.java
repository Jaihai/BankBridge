package Service.impl;

import Service.AddressService;
import Model.Customer;
import Repository.CustomerRepository;
import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import exception.AddressDetailsNotFoundException;
import exception.CustomerIDNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class AddressServiceImpl implements AddressService {

    private final CustomerRepository customerRepo;

    public AddressServiceImpl(CustomerRepository customerRepo) {
        this.customerRepo = customerRepo;
    }

    @Override
    public Long create(CreateAddressDto dto) {
        Customer c = customerRepo.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));
        c.setAddressLine(dto.getAddressLine());
        c.setCity(dto.getCity());
        c.setState(dto.getState());
        c.setPostalCode(dto.getPostalCode());
        c.setCountry(dto.getCountry());
        customerRepo.save(c);
        return c.getCustomerId();
    }

    @Override
    public void updateByCustomerId(Long customerId, UpdateAddressDto dto) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        c.setAddressLine(dto.getAddressLine());
        c.setCity(dto.getCity());
        c.setState(dto.getState());
        c.setPostalCode(dto.getPostalCode());
        c.setCountry(dto.getCountry());
        customerRepo.save(c);
    }

    @Override
    public void deleteByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        c.setAddressLine(null);
        c.setCity(null);
        c.setState(null);
        c.setPostalCode(null);
        c.setCountry(null);
        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AddressDto> listAll() {
        return customerRepo.findAll().stream()
                .filter(c -> c.getAddressLine() != null || c.getCity() != null || c.getCountry() != null)
                .map(c -> {
                    AddressDto dto = new AddressDto();
                    dto.setCustomerId(c.getCustomerId());
                    dto.setAddressLine(c.getAddressLine());
                    dto.setCity(c.getCity());
                    dto.setState(c.getState());
                    dto.setPostalCode(c.getPostalCode());
                    dto.setCountry(c.getCountry());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findByCustomerId(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        if (c.getAddressLine() == null && c.getCity() == null && c.getState() == null
                && c.getPostalCode() == null && c.getCountry() == null) {
            throw new AddressDetailsNotFoundException(customerId);
        }
        AddressDto dto = new AddressDto();
        dto.setCustomerId(c.getCustomerId());
        dto.setAddressLine(c.getAddressLine());
        dto.setCity(c.getCity());
        dto.setState(c.getState());
        dto.setPostalCode(c.getPostalCode());
        dto.setCountry(c.getCountry());
        return dto;
    }
}
