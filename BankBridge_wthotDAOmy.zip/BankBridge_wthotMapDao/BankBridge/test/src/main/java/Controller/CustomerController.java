package Controller;


import Service.CustomerService;
import dto.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/customer")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) { this.customerService = customerService; }

    // POST /bankapi/v1/customer - Add new Customer
    @PostMapping
    public ResponseEntity<String> create(@Valid @RequestBody CreateCustomerDto dto) {
        customerService.create(dto);
        return ResponseEntity.status(201).body("Record Created Successfully");
    }

    // PUT /bankapi/v1/customer - Modify the Customer
    @PutMapping
    public ResponseEntity<String> update(@RequestParam Long id, @Valid @RequestBody UpdateCustomerDto dto) {
        customerService.update(id, dto);
        return ResponseEntity.ok("Record Modified Successfully");
    }

    // GET /bankapi/v1/customer - List all customers
    @GetMapping
    public ResponseEntity<List<CustomerDto>> listAll() {
        return ResponseEntity.ok(customerService.listAll());
    }

    // DELETE /bankapi/v1/customer/{id} - Delete customer by id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        customerService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // GET /bankapi/v1/customer/{id} - Get customer by id
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.get(id));
    }

    // POST /bankapi/v1/customer/login - Login using email & password
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto> login(@Valid @RequestBody LoginRequestDto dto) {
        return ResponseEntity.ok(customerService.login(dto));
    }

    // GET /bankapi/v1/customer/getAllAccounts/{id} - Accounts owned by the customer
    @GetMapping("/getAllAccounts/{id}")
    public ResponseEntity<List<AccountDto>> getAllAccounts(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getAllAccounts(id));
    }

    // GET /bankapi/v1/customer/findAddress/{id} - Address for the given customer id
    @GetMapping("/findAddress/{id}")
    public ResponseEntity<AddressDto> findAddress(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.findAddress(id));
    }
}
