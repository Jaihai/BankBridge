package Repository;

import Model.Transfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TransferRepository extends JpaRepository<Transfer, Long> {
    @Query("SELECT t FROM Transfer t WHERE t.fromAccount.account_id = :accountId OR t.toAccount.account_id = :accountId ORDER BY t.initiated_at DESC")
    List<Transfer> findAllByAccountId(@Param("accountId") Long accountId);

    @Query("SELECT t FROM Transfer t WHERE t.status = :status ORDER BY t.initiated_at DESC")
    List<Transfer> findAllByStatus(@Param("status") String status);
}
