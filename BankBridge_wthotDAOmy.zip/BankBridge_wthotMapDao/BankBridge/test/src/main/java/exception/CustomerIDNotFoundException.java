package exception;

public class CustomerIDNotFoundException extends RuntimeException {
    public CustomerIDNotFoundException(Long id) {
        super("Customer not found with id: " + id);
    }
}
