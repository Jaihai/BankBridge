package dto;

import java.util.List;

public class TransactionSummaryResponse {
    private List<TransactionDto> transactions;

    public TransactionSummaryResponse() { }

    public TransactionSummaryResponse(List<TransactionDto> transactions) {
        this.transactions = transactions;
    }

    public List<TransactionDto> getTransactions() { return transactions; }
    public void setTransactions(List<TransactionDto> transactions) { this.transactions = transactions; }
}