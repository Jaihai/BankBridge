//Payee

package Model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "payee")
public class Payee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payee_id;

    private String payee_name;
    private String payee_account_number;
    private String payee_bank_name;
    private String payee_ifsc;
    private String nickname;
    private String status;
    private LocalDateTime created_at;

    /* ================= RELATIONSHIPS ================= */

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    /* ================= CONSTRUCTORS ================= */

    public Payee() {
        // mandatory no-arg constructor
    }

    /* ================= GETTERS & SETTERS ================= */

    public Long getPayee_id() {
        return payee_id;
    }

    public void setPayee_id(Long payee_id) {
        this.payee_id = payee_id;
    }

    public String getPayee_name() {
        return payee_name;
    }

    public void setPayee_name(String payee_name) {
        this.payee_name = payee_name;
    }

    public String getPayee_account_number() {
        return payee_account_number;
    }

    public void setPayee_account_number(String payee_account_number) {
        this.payee_account_number = payee_account_number;
    }

    public String getPayee_bank_name() {
        return payee_bank_name;
    }

    public void setPayee_bank_name(String payee_bank_name) {
        this.payee_bank_name = payee_bank_name;
    }

    public String getPayee_ifsc() {
        return payee_ifsc;
    }

    public void setPayee_ifsc(String payee_ifsc) {
        this.payee_ifsc = payee_ifsc;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreated_at() {
        return created_at;
    }

    public void setCreated_at(LocalDateTime created_at) {
        this.created_at = created_at;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
