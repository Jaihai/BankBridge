package Model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "customer")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customer_id;

    private String first_name;
    private String last_name;
    private String email;
    @Column(name = "password_hash")
    private String password_hash;
    private String phone;
    private LocalDate date_of_birth;
    private String address_line;
    private String city;
    private String state;
    private String postal_code;
    private String country;
    private LocalDateTime created_at;
    private String status;

    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
    private List<Account> accounts;

    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
    private List<Loan> loans;

    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
    private List<Payee> payees;

    @OneToOne(mappedBy = "customer", fetch = FetchType.LAZY)
    private User user;

    public Customer() {}

    /* Convenience getters/setters for services/mappers (camelCase) */
    public Long getCustomerId() { return customer_id; }
    public void setCustomerId(Long id) { this.customer_id = id; }
    public String getFirstName() { return first_name; }
    public void setFirstName(String v) { this.first_name = v; }
    public String getLastName() { return last_name; }
    public void setLastName(String v) { this.last_name = v; }
    public String getPasswordHash() { return password_hash; }
    public void setPasswordHash(String v) { this.password_hash = v; }
    public LocalDateTime getCreatedAt() { return created_at; }
    public void setCreatedAt(LocalDateTime v) { this.created_at = v; }
    public String getAddressLine() { return address_line; }
    public void setAddressLine(String v) { this.address_line = v; }
    public String getPostalCode() { return postal_code; }
    public void setPostalCode(String v) { this.postal_code = v; }

    public Long getCustomer_id() { return customer_id; }
    public void setCustomer_id(Long customer_id) { this.customer_id = customer_id; }
    public String getFirst_name() { return first_name; }
    public void setFirst_name(String first_name) { this.first_name = first_name; }
    public String getLast_name() { return last_name; }
    public void setLast_name(String last_name) { this.last_name = last_name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public LocalDate getDate_of_birth() { return date_of_birth; }
    public void setDate_of_birth(LocalDate date_of_birth) { this.date_of_birth = date_of_birth; }
    public String getAddress_line() { return address_line; }
    public void setAddress_line(String address_line) { this.address_line = address_line; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getPostal_code() { return postal_code; }
    public void setPostal_code(String postal_code) { this.postal_code = postal_code; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public LocalDateTime getCreated_at() { return created_at; }
    public void setCreated_at(LocalDateTime created_at) { this.created_at = created_at; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public List<Account> getAccounts() { return accounts; }
    public void setAccounts(List<Account> accounts) { this.accounts = accounts; }
    public List<Loan> getLoans() { return loans; }
    public void setLoans(List<Loan> loans) { this.loans = loans; }
    public List<Payee> getPayees() { return payees; }
    public void setPayees(List<Payee> payees) { this.payees = payees; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
