//LoanPayment
package Model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "loan_payment")
public class LoanPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payment_id;

    private LocalDate due_date;
    private LocalDate paid_date;
    private BigDecimal amount_due;
    private BigDecimal amount_paid;
    private BigDecimal penalty_amount;
    private String status;

    /* ================= RELATIONSHIPS ================= */

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "loan_id")
    private Loan loan;

    /* ================= CONSTRUCTORS ================= */

    public LoanPayment() {
        // mandatory no-arg constructor for JPA
    }

    /* ================= GETTERS & SETTERS ================= */

    public Long getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(Long payment_id) {
        this.payment_id = payment_id;
    }

    public LocalDate getDue_date() {
        return due_date;
    }

    public void setDue_date(LocalDate due_date) {
        this.due_date = due_date;
    }

    public LocalDate getPaid_date() {
        return paid_date;
    }

    public void setPaid_date(LocalDate paid_date) {
        this.paid_date = paid_date;
    }

    public BigDecimal getAmount_due() {
        return amount_due;
    }

    public void setAmount_due(BigDecimal amount_due) {
        this.amount_due = amount_due;
    }

    public BigDecimal getAmount_paid() {
        return amount_paid;
    }

    public void setAmount_paid(BigDecimal amount_paid) {
        this.amount_paid = amount_paid;
    }

    public BigDecimal getPenalty_amount() {
        return penalty_amount;
    }

    public void setPenalty_amount(BigDecimal penalty_amount) {
        this.penalty_amount = penalty_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }
}
