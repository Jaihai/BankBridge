package Service;

import dto.TransferDto;
import dto.CreateTransferDto;
import dto.UpdateTransferDto;

import java.util.List;

public interface TransferService {
    Long create(CreateTransferDto dto);
    void update(Long id, UpdateTransferDto dto);
    TransferDto get(Long id);
    List<TransferDto> listAll();
    List<TransferDto> listByAccountId(Long accountId);
    List<TransferDto> listByStatus(String status);
    void delete(Long id);
}
