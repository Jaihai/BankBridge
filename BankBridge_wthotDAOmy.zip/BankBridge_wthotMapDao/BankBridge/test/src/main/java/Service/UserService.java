package Service;

import dto.UserDto;
import dto.CreateUserDto;
import dto.UpdateUserDto;

import java.util.List;

public interface UserService {
    Long create(CreateUserDto dto);
    void update(Long id, UpdateUserDto dto);
    UserDto get(Long id);
    UserDto getByUsername(String username);
    List<UserDto> listAll();
    List<UserDto> listByCustomerId(Long customerId);
    void delete(Long id);
}
