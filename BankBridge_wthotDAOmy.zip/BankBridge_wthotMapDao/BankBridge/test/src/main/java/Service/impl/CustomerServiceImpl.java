package Service.impl;

import Service.CustomerService;
import Model.Account;
import Model.Customer;
import Repository.AccountRepository;
import Repository.CustomerRepository;
import dto.*;
import exception.CustomerDBEmptyException;
import exception.CustomerIDNotFoundException;
import exception.AddressDetailsNotFoundException;
import exception.InvalidLoginException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepo;
    private final AccountRepository accountRepo;
    private final PasswordEncoder passwordEncoder;

    public CustomerServiceImpl(CustomerRepository customerRepo,
                               AccountRepository accountRepo,
                               PasswordEncoder passwordEncoder) {
        this.customerRepo = customerRepo;
        this.accountRepo = accountRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Long create(CreateCustomerDto dto) {
        customerRepo.findByEmail(dto.getEmail()).ifPresent(x -> {
            throw new IllegalArgumentException("Email already exists");
        });

        Customer c = new Customer();
        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setEmail(dto.getEmail());
        c.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        c.setStatus("ACTIVE");
        c.setCreated_at(LocalDateTime.now());

        Customer saved = customerRepo.save(c);
        return saved.getCustomerId();
    }

    @Override
    public void update(Long id, UpdateCustomerDto dto) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));
        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setPhone(dto.getPhone());
        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerDto> listAll() {
        List<Customer> customers = customerRepo.findAll();
        if (customers.isEmpty()) {
            throw new CustomerDBEmptyException();
        }
        return customers.stream()
                .map(c -> {
                    CustomerDto dto = new CustomerDto();
                    dto.setId(c.getCustomerId());
                    dto.setFirstName(c.getFirstName());
                    dto.setLastName(c.getLastName());
                    dto.setEmail(c.getEmail());
                    dto.setPhone(c.getPhone());
                    dto.setStatus(c.getStatus());
                    dto.setCreatedAt(c.getCreated_at());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDto get(Long id) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));
        CustomerDto dto = new CustomerDto();
        dto.setId(c.getCustomerId());
        dto.setFirstName(c.getFirstName());
        dto.setLastName(c.getLastName());
        dto.setEmail(c.getEmail());
        dto.setPhone(c.getPhone());
        dto.setStatus(c.getStatus());
        dto.setCreatedAt(c.getCreated_at());
        return dto;
    }

    @Override
    public void delete(Long id) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new CustomerIDNotFoundException(id));
        customerRepo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public LoginResponseDto login(LoginRequestDto dto) {
        Customer c = customerRepo.findByEmail(dto.getEmail())
                .orElseThrow(InvalidLoginException::new);

        boolean ok = passwordEncoder.matches(dto.getPassword(), c.getPasswordHash());
        if (!ok) throw new InvalidLoginException();

        return new LoginResponseDto(c.getCustomerId(), c.getFirstName(), c.getLastName(), c.getEmail());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> getAllAccounts(Long customerId) {
        customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        List<Account> accounts = accountRepo.findAllByCustomerId(customerId);
        return accounts.stream()
                .map(acc -> {
                    AccountDto dto = new AccountDto();
                    dto.setId(acc.getAccount_id());
                    dto.setCustomerId(acc.getCustomer() != null ? acc.getCustomer().getCustomerId() : null);
                    dto.setAccountNumber(acc.getAccount_number());
                    dto.setAccountType(acc.getAccount_type());
                    dto.setCurrency(acc.getCurrency());
                    dto.setBalance(acc.getBalance());
                    dto.setStatus(acc.getStatus());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findAddress(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        if (c.getAddress_line() == null && c.getCity() == null && c.getState() == null
                && c.getPostal_code() == null && c.getCountry() == null) {
            throw new AddressDetailsNotFoundException(customerId);
        }
        AddressDto dto = new AddressDto();
        dto.setCustomerId(c.getCustomerId());
        dto.setAddressLine(c.getAddress_line());
        dto.setCity(c.getCity());
        dto.setState(c.getState());
        dto.setPostalCode(c.getPostal_code());
        dto.setCountry(c.getCountry());
        return dto;
    }
}
