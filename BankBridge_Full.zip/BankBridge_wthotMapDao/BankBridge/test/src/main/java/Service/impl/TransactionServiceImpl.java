package Service.impl;

import Model.Account;
import Model.Transaction;
import Repository.AccountRepository;
import Repository.TransactionRepository;
import Service.TransactionService;
import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;
import exception.AccountNotFoundException;
import exception.InSufficientBalanceException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepo;
    private final TransactionRepository txnRepo;

    public TransactionServiceImpl(AccountRepository accountRepo,
                                  TransactionRepository txnRepo) {
        this.accountRepo = accountRepo;
        this.txnRepo = txnRepo;
    }

    @Override
    public String deposit(DepositRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getAccountNumber()));

        BigDecimal current = a.getBalance() != null ? a.getBalance() : BigDecimal.ZERO;
        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        BigDecimal newBal = current.add(amount);
        a.setBalance(newBal);

        Transaction t = new Transaction();
        t.setAccount(a);
        t.setTxn_type("credit");
        t.setAmount(amount);
        t.setCurrency(a.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("DEPOSIT");
        t.setDescription("Cash deposit");
        t.setBalance_after(newBal);
        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Created Successfully";
    }

    @Override
    public String withdraw(WithdrawRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getAccountNumber()));

        BigDecimal current = a.getBalance() != null ? a.getBalance() : BigDecimal.ZERO;
        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        if (current.compareTo(amount) < 0) {
            throw new InSufficientBalanceException();
        }

        BigDecimal newBal = current.subtract(amount);
        a.setBalance(newBal);

        Transaction t = new Transaction();
        t.setAccount(a);
        t.setTxn_type("debit");
        t.setAmount(amount);
        t.setCurrency(a.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("WITHDRAW");
        t.setDescription("Cash withdrawal");
        t.setBalance_after(newBal);
        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Modified Successfully";
    }

    @Override
    public String fundTransfer(FundTransferRequest req) {
        Account from = accountRepo.findByAccountNumber(req.getFromAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getFromAccountNumber()));
        Account to = accountRepo.findByAccountNumber(req.getToAccountNumber())
                .orElseThrow(() -> new AccountNotFoundException(req.getToAccountNumber()));

        BigDecimal amount = BigDecimal.valueOf(req.getAmount());
        BigDecimal fromBal = from.getBalance() != null ? from.getBalance() : BigDecimal.ZERO;
        if (fromBal.compareTo(amount) < 0) {
            throw new InSufficientBalanceException();
        }

        from.setBalance(fromBal.subtract(amount));
        Transaction debit = new Transaction();
        debit.setAccount(from);
        debit.setTxn_type("debit");
        debit.setAmount(amount);
        debit.setCurrency(from.getCurrency());
        debit.setPosted_at(LocalDateTime.now());
        debit.setReference("TRANSFER");
        debit.setDescription("Fund transfer - debit");
        debit.setBalance_after(from.getBalance());

        BigDecimal toBal = to.getBalance() != null ? to.getBalance() : BigDecimal.ZERO;
        BigDecimal newToBal = toBal.add(amount);
        to.setBalance(newToBal);
        Transaction credit = new Transaction();
        credit.setAccount(to);
        credit.setTxn_type("credit");
        credit.setAmount(amount);
        credit.setCurrency(to.getCurrency());
        credit.setPosted_at(LocalDateTime.now());
        credit.setReference("TRANSFER");
        credit.setDescription("Fund transfer - credit");
        credit.setBalance_after(newToBal);

        txnRepo.save(debit);
        txnRepo.save(credit);
        accountRepo.save(from);
        accountRepo.save(to);

        return "Record Modified Successfully";
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> summary(LocalDateTime from, LocalDateTime to) {
        return txnRepo.findAllBetween(from, to).stream()
                .map(t -> {
                    TransactionDto dto = new TransactionDto();
                    dto.setId(t.getTransaction_id());
                    dto.setAccountNumber(t.getAccount() != null ? t.getAccount().getAccount_number() : null);
                    dto.setTxnType(t.getTxn_type());
                    dto.setAmount(t.getAmount());
                    dto.setCurrency(t.getCurrency());
                    dto.setPostedAt(t.getPosted_at());
                    dto.setReference(t.getReference());
                    dto.setDescription(t.getDescription());
                    dto.setBalanceAfter(t.getBalance_after());
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
