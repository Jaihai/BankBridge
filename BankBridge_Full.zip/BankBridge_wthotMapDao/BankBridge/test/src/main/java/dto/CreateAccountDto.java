package dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public class CreateAccountDto {
    @NotNull
    private Long customerId;
    @NotNull
    private Long branchId;
    @NotBlank
    private String accountType;
    @NotBlank
    private String currency;
    @NotNull @Positive
    private BigDecimal initialDeposit;

    public CreateAccountDto() { }

    public CreateAccountDto(Long customerId, Long branchId, String accountType, String currency, BigDecimal initialDeposit) {
        this.customerId = customerId;
        this.branchId = branchId;
        this.accountType = accountType;
        this.currency = currency;
        this.initialDeposit = initialDeposit;
    }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public Long getBranchId() { return branchId; }
    public void setBranchId(Long branchId) { this.branchId = branchId; }

    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public BigDecimal getInitialDeposit() { return initialDeposit; }
    public void setInitialDeposit(BigDecimal initialDeposit) { this.initialDeposit = initialDeposit; }
}