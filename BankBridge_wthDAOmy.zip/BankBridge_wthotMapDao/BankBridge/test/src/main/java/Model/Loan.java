//Loan
package Model
;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "loan")
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long loan_id;

    private String loan_number;
    private String loan_type;
    private BigDecimal principal_amount;
    private BigDecimal interest_rate;
    private Integer term_months;
    private LocalDate start_date;
    private LocalDate maturity_date;
    private String status;

    /* ================= RELATIONSHIPS ================= */

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @OneToMany(mappedBy = "loan", fetch = FetchType.LAZY)
    private List<LoanPayment> payments;

    /* ================= CONSTRUCTORS ================= */

    public Loan() {
        // mandatory no-arg constructor for JPA
    }

    /* ================= GETTERS & SETTERS ================= */

    public Long getLoan_id() {
        return loan_id;
    }

    public void setLoan_id(Long loan_id) {
        this.loan_id = loan_id;
    }

    public String getLoan_number() {
        return loan_number;
    }

    public void setLoan_number(String loan_number) {
        this.loan_number = loan_number;
    }

    public String getLoan_type() {
        return loan_type;
    }

    public void setLoan_type(String loan_type) {
        this.loan_type = loan_type;
    }

    public BigDecimal getPrincipal_amount() {
        return principal_amount;
    }

    public void setPrincipal_amount(BigDecimal principal_amount) {
        this.principal_amount = principal_amount;
    }

    public BigDecimal getInterest_rate() {
        return interest_rate;
    }

    public void setInterest_rate(BigDecimal interest_rate) {
        this.interest_rate = interest_rate;
    }

    public Integer getTerm_months() {
        return term_months;
    }

    public void setTerm_months(Integer term_months) {
        this.term_months = term_months;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public LocalDate getMaturity_date() {
        return maturity_date;
    }

    public void setMaturity_date(LocalDate maturity_date) {
        this.maturity_date = maturity_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public List<LoanPayment> getPayments() {
        return payments;
    }

    public void setPayments(List<LoanPayment> payments) {
        this.payments = payments;
    }
}
