package DAO.impl;

import DAO.TransactionDAO;
import Model.Transaction;
import Repository.TransactionRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public class TransactionDAOImpl implements TransactionDAO {

    private final TransactionRepository transactionRepository;

    public TransactionDAOImpl(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public Transaction save(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    @Override
    public List<Transaction> findAllBetween(LocalDateTime from, LocalDateTime to) {
        return transactionRepository.findAllBetween(from, to);
    }

    @Override
    public List<Transaction> findAll() {
        return transactionRepository.findAll();
    }
}
