package DAO;

import Model.Transfer;

import java.util.List;
import java.util.Optional;

public interface TransferDAO {
    Transfer save(Transfer transfer);
    Optional<Transfer> findById(Long id);
    List<Transfer> findAll();
    List<Transfer> findAllByAccountId(Long accountId);
    List<Transfer> findAllByStatus(String status);
    void deleteById(Long id);
}
