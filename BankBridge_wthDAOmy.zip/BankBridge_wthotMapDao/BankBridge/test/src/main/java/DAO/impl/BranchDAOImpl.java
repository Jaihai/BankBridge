package DAO.impl;

import DAO.BranchDAO;
import Model.Branch;
import Repository.BranchRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class BranchDAOImpl implements BranchDAO {

    private final BranchRepository branchRepository;

    public BranchDAOImpl(BranchRepository branchRepository) {
        this.branchRepository = branchRepository;
    }

    @Override
    public Branch save(Branch branch) {
        return branchRepository.save(branch);
    }

    @Override
    public Optional<Branch> findById(Long id) {
        return branchRepository.findById(id);
    }
}
