package DAO;

import Model.Customer;
import java.util.List;
import java.util.Optional;

public interface CustomerDAO {
    Customer save(Customer customer);
    Optional<Customer> findById(Long id);
    Optional<Customer> findByEmail(String email);
    List<Customer> findAll();
    void deleteById(Long id);
}
