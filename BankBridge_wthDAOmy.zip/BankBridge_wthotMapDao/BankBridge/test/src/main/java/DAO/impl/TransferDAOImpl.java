package DAO.impl;

import DAO.TransferDAO;
import Model.Transfer;
import Repository.TransferRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class TransferDAOImpl implements TransferDAO {

    private final TransferRepository transferRepository;

    public TransferDAOImpl(TransferRepository transferRepository) {
        this.transferRepository = transferRepository;
    }

    @Override
    public Transfer save(Transfer transfer) {
        return transferRepository.save(transfer);
    }

    @Override
    public Optional<Transfer> findById(Long id) {
        return transferRepository.findById(id);
    }

    @Override
    public List<Transfer> findAll() {
        return transferRepository.findAll();
    }

    @Override
    public List<Transfer> findAllByAccountId(Long accountId) {
        return transferRepository.findAllByAccountId(accountId);
    }

    @Override
    public List<Transfer> findAllByStatus(String status) {
        return transferRepository.findAllByStatus(status);
    }

    @Override
    public void deleteById(Long id) {
        transferRepository.deleteById(id);
    }
}
