package Controller;

import Service.TransferService;
import dto.TransferDto;
import dto.CreateTransferDto;
import dto.UpdateTransferDto;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/transfer")
public class TransferController {

    private final TransferService transferService;

    public TransferController(TransferService transferService) {
        this.transferService = transferService;
    }

    @PostMapping
    public ResponseEntity<String> create(@Valid @RequestBody CreateTransferDto dto) {
        transferService.create(dto);
        return ResponseEntity.status(201).body("Record Created Successfully");
    }

    @PutMapping
    public ResponseEntity<String> update(@RequestParam Long id, @RequestBody UpdateTransferDto dto) {
        transferService.update(id, dto);
        return ResponseEntity.ok("Record Modified Successfully");
    }

    @GetMapping
    public ResponseEntity<List<TransferDto>> listAll() {
        return ResponseEntity.ok(transferService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransferDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(transferService.get(id));
    }

    @GetMapping("/by-account/{accountId}")
    public ResponseEntity<List<TransferDto>> listByAccountId(@PathVariable Long accountId) {
        return ResponseEntity.ok(transferService.listByAccountId(accountId));
    }

    @GetMapping("/by-status")
    public ResponseEntity<List<TransferDto>> listByStatus(@RequestParam String status) {
        return ResponseEntity.ok(transferService.listByStatus(status));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        transferService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
