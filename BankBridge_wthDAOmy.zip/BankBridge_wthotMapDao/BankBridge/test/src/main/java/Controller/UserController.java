package Controller;

import Service.UserService;
import dto.UserDto;
import dto.CreateUserDto;
import dto.UpdateUserDto;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<String> create(@Valid @RequestBody CreateUserDto dto) {
        userService.create(dto);
        return ResponseEntity.status(201).body("Record Created Successfully");
    }

    @PutMapping
    public ResponseEntity<String> update(@RequestParam Long id, @RequestBody UpdateUserDto dto) {
        userService.update(id, dto);
        return ResponseEntity.ok("Record Modified Successfully");
    }

    @GetMapping
    public ResponseEntity<List<UserDto>> listAll() {
        return ResponseEntity.ok(userService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(userService.get(id));
    }

    @GetMapping("/username/{username}")
    public ResponseEntity<UserDto> getByUsername(@PathVariable String username) {
        return ResponseEntity.ok(userService.getByUsername(username));
    }

    @GetMapping("/by-customer/{customerId}")
    public ResponseEntity<List<UserDto>> listByCustomerId(@PathVariable Long customerId) {
        return ResponseEntity.ok(userService.listByCustomerId(customerId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
