package Service.impl;

import Model.Account;
import Model.Branch;
import Model.Customer;
import DAO.AccountDAO;
import DAO.BranchDAO;
import DAO.CustomerDAO;
import Service.AccountService;
import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import exception.AccountCloseException;
import exception.AccountNotFoundException;
import exception.CustomerIDNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

    private final AccountDAO accountDAO;
    private final CustomerDAO customerDAO;
    private final BranchDAO branchDAO;

    public AccountServiceImpl(AccountDAO accountDAO,
                              CustomerDAO customerDAO,
                              BranchDAO branchDAO) {
        this.accountDAO = accountDAO;
        this.customerDAO = customerDAO;
        this.branchDAO = branchDAO;
    }

    @Override
    public Long create(CreateAccountDto dto) {
        Customer customer = customerDAO.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));
        Branch branch = branchDAO.findById(dto.getBranchId())
                .orElseThrow(() -> new RuntimeException("Branch not found: " + dto.getBranchId()));
        String accountNumber = "ACC" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        
        Account entity = new Account();
        entity.setCustomer(customer);
        entity.setBranch(branch);
        entity.setAccount_number(accountNumber);
        entity.setAccount_type(dto.getAccountType());
        entity.setCurrency(dto.getCurrency());
        entity.setBalance(dto.getInitialDeposit() != null ? dto.getInitialDeposit() : BigDecimal.ZERO);
        entity.setStatus("OPEN");
        entity.setOpened_at(LocalDateTime.now());
        
        return accountDAO.save(entity).getAccount_id();
    }

    @Override
    public void update(Long id, UpdateAccountDto dto) {
        Account entity = accountDAO.findById(id)
                .orElseThrow(() -> new AccountNotFoundException(id));
        if (dto.getAccountType() != null) {
            entity.setAccount_type(dto.getAccountType());
        }
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
        accountDAO.save(entity);
    }

    @Override
    @Transactional(readOnly = true)
    public AccountDto get(Long id) {
        Account account = accountDAO.findById(id)
                .orElseThrow(() -> new AccountNotFoundException(id));
        AccountDto dto = new AccountDto();
        dto.setId(account.getAccount_id());
        dto.setCustomerId(account.getCustomer() != null ? account.getCustomer().getCustomerId() : null);
        dto.setAccountNumber(account.getAccount_number());
        dto.setAccountType(account.getAccount_type());
        dto.setCurrency(account.getCurrency());
        dto.setBalance(account.getBalance());
        dto.setStatus(account.getStatus());
        return dto;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> listAll() {
        return accountDAO.findAll().stream()
                .map(acc -> {
                    AccountDto dto = new AccountDto();
                    dto.setId(acc.getAccount_id());
                    dto.setCustomerId(acc.getCustomer() != null ? acc.getCustomer().getCustomerId() : null);
                    dto.setAccountNumber(acc.getAccount_number());
                    dto.setAccountType(acc.getAccount_type());
                    dto.setCurrency(acc.getCurrency());
                    dto.setBalance(acc.getBalance());
                    dto.setStatus(acc.getStatus());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        Account entity = accountDAO.findById(id)
                .orElseThrow(() -> new AccountNotFoundException(id));
        BigDecimal balance = entity.getBalance();
        if (balance != null && balance.compareTo(BigDecimal.ZERO) != 0) {
            throw new AccountCloseException();
        }
        accountDAO.deleteById(id);
    }
}
