package Service.impl;

import DAO.CustomerDAO;
import DAO.UserDAO;
import Model.Customer;
import Model.User;
import Service.UserService;
import dto.UserDto;
import dto.CreateUserDto;
import dto.UpdateUserDto;
import exception.CustomerIDNotFoundException;
import exception.UserNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    private final UserDAO userDAO;
    private final CustomerDAO customerDAO;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserDAO userDAO, CustomerDAO customerDAO, PasswordEncoder passwordEncoder) {
        this.userDAO = userDAO;
        this.customerDAO = customerDAO;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Long create(CreateUserDto dto) {
        userDAO.findByUsername(dto.getUsername()).ifPresent(x -> {
            throw new IllegalArgumentException("Username already exists");
        });
        Customer customer = customerDAO.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));

        User u = new User();
        u.setUsername(dto.getUsername());
        u.setPassword_hash(passwordEncoder.encode(dto.getPassword()));
        u.setEmail(dto.getEmail());
        u.setPhone(dto.getPhone());
        u.setRole(dto.getRole() != null ? dto.getRole() : "USER");
        u.setMfa_enabled(false);
        u.setStatus("ACTIVE");
        u.setCreated_at(LocalDateTime.now());
        u.setCustomer(customer);

        return userDAO.save(u).getUser_id();
    }

    @Override
    public void update(Long id, UpdateUserDto dto) {
        User u = userDAO.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        if (dto.getEmail() != null) u.setEmail(dto.getEmail());
        if (dto.getPhone() != null) u.setPhone(dto.getPhone());
        if (dto.getRole() != null) u.setRole(dto.getRole());
        if (dto.getStatus() != null) u.setStatus(dto.getStatus());
        userDAO.save(u);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDto get(Long id) {
        User u = userDAO.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        return toDto(u);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDto getByUsername(String username) {
        User u = userDAO.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException(username));
        return toDto(u);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> listAll() {
        return userDAO.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> listByCustomerId(Long customerId) {
        customerDAO.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        return userDAO.findByCustomerId(customerId).stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        if (!userDAO.findById(id).isPresent()) {
            throw new UserNotFoundException(id);
        }
        userDAO.deleteById(id);
    }

    private UserDto toDto(User u) {
        UserDto dto = new UserDto();
        dto.setId(u.getUser_id());
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());
        dto.setPhone(u.getPhone());
        dto.setRole(u.getRole());
        dto.setMfaEnabled(u.getMfa_enabled());
        dto.setLastLoginAt(u.getLast_login_at());
        dto.setStatus(u.getStatus());
        dto.setCreatedAt(u.getCreated_at());
        dto.setCustomerId(u.getCustomer() != null ? u.getCustomer().getCustomerId() : null);
        return dto;
    }
}
