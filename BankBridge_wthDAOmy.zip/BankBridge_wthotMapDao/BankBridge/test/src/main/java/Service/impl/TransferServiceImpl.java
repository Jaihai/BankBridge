package Service.impl;

import DAO.AccountDAO;
import DAO.TransferDAO;
import Model.Account;
import Model.Transfer;
import Service.TransferService;
import dto.TransferDto;
import dto.CreateTransferDto;
import dto.UpdateTransferDto;
import exception.AccountNotFoundException;
import exception.TransferNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class TransferServiceImpl implements TransferService {

    private final TransferDAO transferDAO;
    private final AccountDAO accountDAO;

    public TransferServiceImpl(TransferDAO transferDAO, AccountDAO accountDAO) {
        this.transferDAO = transferDAO;
        this.accountDAO = accountDAO;
    }

    @Override
    public Long create(CreateTransferDto dto) {
        Account from = accountDAO.findById(dto.getFromAccountId())
                .orElseThrow(() -> new AccountNotFoundException(dto.getFromAccountId()));
        Account to = accountDAO.findById(dto.getToAccountId())
                .orElseThrow(() -> new AccountNotFoundException(dto.getToAccountId()));

        Transfer t = new Transfer();
        t.setFromAccount(from);
        t.setToAccount(to);
        t.setAmount(dto.getAmount());
        t.setCurrency(dto.getCurrency() != null ? dto.getCurrency() : from.getCurrency());
        t.setInitiated_at(LocalDateTime.now());
        t.setStatus("PENDING");
        t.setChannel(dto.getChannel());
        t.setReference(dto.getReference());

        return transferDAO.save(t).getTransfer_id();
    }

    @Override
    public void update(Long id, UpdateTransferDto dto) {
        Transfer t = transferDAO.findById(id)
                .orElseThrow(() -> new TransferNotFoundException(id));
        if (dto.getCompletedAt() != null) {
            t.setCompleted_at(dto.getCompletedAt());
        }
        if (dto.getStatus() != null) {
            t.setStatus(dto.getStatus());
        }
        transferDAO.save(t);
    }

    @Override
    @Transactional(readOnly = true)
    public TransferDto get(Long id) {
        Transfer t = transferDAO.findById(id)
                .orElseThrow(() -> new TransferNotFoundException(id));
        return toDto(t);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferDto> listAll() {
        return transferDAO.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferDto> listByAccountId(Long accountId) {
        return transferDAO.findAllByAccountId(accountId).stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferDto> listByStatus(String status) {
        return transferDAO.findAllByStatus(status).stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        if (!transferDAO.findById(id).isPresent()) {
            throw new TransferNotFoundException(id);
        }
        transferDAO.deleteById(id);
    }

    private TransferDto toDto(Transfer t) {
        TransferDto dto = new TransferDto();
        dto.setId(t.getTransfer_id());
        dto.setFromAccountId(t.getFromAccount() != null ? t.getFromAccount().getAccount_id() : null);
        dto.setToAccountId(t.getToAccount() != null ? t.getToAccount().getAccount_id() : null);
        dto.setAmount(t.getAmount());
        dto.setCurrency(t.getCurrency());
        dto.setInitiatedAt(t.getInitiated_at());
        dto.setCompletedAt(t.getCompleted_at());
        dto.setStatus(t.getStatus());
        dto.setChannel(t.getChannel());
        dto.setReference(t.getReference());
        return dto;
    }
}
