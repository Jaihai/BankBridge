package dto;

import jakarta.validation.constraints.NotBlank;

public class UpdateAccountDto {

    @NotBlank
    private String accountType;

    // Optional; when null we won't change the entity's current status
    private String status;

    public UpdateAccountDto() {
    }

    public UpdateAccountDto(String accountType, String status) {
        this.accountType = accountType;
        this.status = status;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}