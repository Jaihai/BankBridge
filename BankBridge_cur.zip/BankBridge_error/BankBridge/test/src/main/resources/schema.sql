-- Bank Application Schema (PostgreSQL)
-- Run this for fresh DB or reference

CREATE TABLE IF NOT EXISTS customer (
    customer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    phone VARCHAR(30),
    date_of_birth DATE,
    address_line VARCHAR(255),
    city VARCHAR(120),
    state VARCHAR(120),
    postal_code VARCHAR(20),
    country VARCHAR(120),
    created_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(30) DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS branch (
    branch_id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    ifsc_code VARCHAR(20) UNIQUE NOT NULL,
    address VARCHAR(255),
    city VARCHAR(120),
    state VARCHAR(120),
    postal_code VARCHAR(20),
    country VARCHAR(120),
    phone VARCHAR(30)
);

CREATE TABLE IF NOT EXISTS account (
    account_id SERIAL PRIMARY KEY,
    customer_id INT NOT NULL REFERENCES customer(customer_id),
    branch_id INT NOT NULL REFERENCES branch(branch_id),
    account_number VARCHAR(34) UNIQUE NOT NULL,
    account_type VARCHAR(30) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    balance NUMERIC(18,2) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
    opened_at TIMESTAMP DEFAULT NOW(),
    closed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transaction (
    transaction_id SERIAL PRIMARY KEY,
    account_id INT NOT NULL REFERENCES account(account_id),
    txn_type VARCHAR(10) NOT NULL CHECK (txn_type IN ('credit','debit')),
    amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) NOT NULL,
    posted_at TIMESTAMP DEFAULT NOW(),
    reference VARCHAR(64),
    description VARCHAR(255),
    balance_after NUMERIC(18,2)
);

CREATE INDEX IF NOT EXISTS idx_account_customer ON account(customer_id);
CREATE INDEX IF NOT EXISTS idx_account_branch ON account(branch_id);
CREATE INDEX IF NOT EXISTS idx_txn_account_posted ON transaction(account_id, posted_at DESC);
