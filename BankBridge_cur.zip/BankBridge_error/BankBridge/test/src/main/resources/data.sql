-- Seed default branch if none exists (for account creation)
-- PostgreSQL syntax
INSERT INTO branch (name, ifsc_code, address, city, state, postal_code, country, phone)
SELECT 'Main Branch', 'MAIN0001', '123 Bank St', 'Mumbai', 'MH', '400001', 'India', '+91-22-12345678'
WHERE NOT EXISTS (SELECT 1 FROM branch LIMIT 1);
