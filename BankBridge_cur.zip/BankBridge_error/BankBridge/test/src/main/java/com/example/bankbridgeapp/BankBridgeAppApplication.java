package com.example.bankbridgeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.example.bankbridgeapp",
    "Controller", "Service", "Model", "Repository", "Mapper",
    "ExceptionHandler", "exception", "config"
})
@EnableJpaRepositories(basePackages = {"Repository"})
@EntityScan(basePackages = {"Model"})
public class BankBridgeAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(BankBridgeAppApplication.class, args);
    }
}