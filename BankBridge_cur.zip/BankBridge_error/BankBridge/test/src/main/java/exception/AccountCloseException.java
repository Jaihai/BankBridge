package exception;

public class AccountCloseException extends RuntimeException {
    public AccountCloseException() {
        super("Cannot close account with non-zero balance");
    }
}
