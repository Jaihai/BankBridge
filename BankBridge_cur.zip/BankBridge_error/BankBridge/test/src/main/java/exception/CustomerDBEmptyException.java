package exception;

public class CustomerDBEmptyException extends RuntimeException {
    public CustomerDBEmptyException() {
        super("No customers available in database");
    }
}
