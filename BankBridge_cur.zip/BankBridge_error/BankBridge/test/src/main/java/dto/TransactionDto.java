package dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionDto {
    private Long id;
    private String accountNumber;
    private String txnType;
    private BigDecimal amount;
    private String currency;
    private LocalDateTime postedAt;
    private String reference;
    private String description;
    private BigDecimal balanceAfter;

    public TransactionDto() { }

    public TransactionDto(Long id, String accountNumber, String txnType, BigDecimal amount,
                          String currency, LocalDateTime postedAt, String reference,
                          String description, BigDecimal balanceAfter) {
        this.id = id;
        this.accountNumber = accountNumber;
        this.txnType = txnType;
        this.amount = amount;
        this.currency = currency;
        this.postedAt = postedAt;
        this.reference = reference;
        this.description = description;
        this.balanceAfter = balanceAfter;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getTxnType() { return txnType; }
    public void setTxnType(String txnType) { this.txnType = txnType; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public LocalDateTime getPostedAt() { return postedAt; }
    public void setPostedAt(LocalDateTime postedAt) { this.postedAt = postedAt; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public void setBalanceAfter(BigDecimal balanceAfter) { this.balanceAfter = balanceAfter; }
}