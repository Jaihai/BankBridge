package dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class UpdateCustomerDto {
    @NotBlank
    private String firstName;
    @NotBlank
    private String lastName;
    @Pattern(regexp="\\+?[0-9\\- ]{7,30}")
    private String phone;

    public UpdateCustomerDto() { }

    public UpdateCustomerDto(String firstName, String lastName, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}