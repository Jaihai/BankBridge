package Mapper;

import Model.Account;
import Model.Transaction;
import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class TransactionMapper {

    public TransactionDto toDto(Transaction t) {
        if (t == null) return null;
        Long id = t.getTransaction_id();
        String accountNumber = t.getAccount() != null ? t.getAccount().getAccount_number() : null;
        return new TransactionDto(
                id,
                accountNumber,
                t.getTxn_type(),
                t.getAmount(),
                t.getCurrency(),
                t.getPosted_at(),
                t.getReference(),
                t.getDescription(),
                t.getBalance_after()
        );
    }

    public List<TransactionDto> toDtoList(List<Transaction> txns) {
        if (txns == null || txns.isEmpty()) return List.of();
        return txns.stream().map(this::toDto).toList();
    }

    public Transaction creditFromDeposit(Account account, DepositRequest req) {
        Transaction t = new Transaction();
        t.setAccount(account);
        t.setTxn_type("credit");
        t.setAmount(BigDecimal.valueOf(req.getAmount()));
        t.setCurrency(account.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("DEPOSIT");
        t.setDescription("Cash deposit");
        return t;
    }

    public Transaction debitFromWithdraw(Account account, WithdrawRequest req) {
        Transaction t = new Transaction();
        t.setAccount(account);
        t.setTxn_type("debit");
        t.setAmount(BigDecimal.valueOf(req.getAmount()));
        t.setCurrency(account.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("WITHDRAW");
        t.setDescription("Cash withdrawal");
        return t;
    }

    public Transaction debitFromTransfer(Account from, FundTransferRequest req) {
        Transaction t = new Transaction();
        t.setAccount(from);
        t.setTxn_type("debit");
        t.setAmount(BigDecimal.valueOf(req.getAmount()));
        t.setCurrency(from.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("TRANSFER");
        t.setDescription("Fund transfer - debit");
        return t;
    }

    public Transaction creditFromTransfer(Account to, FundTransferRequest req) {
        Transaction t = new Transaction();
        t.setAccount(to);
        t.setTxn_type("credit");
        t.setAmount(BigDecimal.valueOf(req.getAmount()));
        t.setCurrency(to.getCurrency());
        t.setPosted_at(LocalDateTime.now());
        t.setReference("TRANSFER");
        t.setDescription("Fund transfer - credit");
        return t;
    }
}
