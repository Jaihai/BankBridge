package Mapper;

import dto.*;
import Model.Customer;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

public class CustomerMapper {


   
    

    // ===== Entity -> DTO =====
    public CustomerDto toDto(Customer c) {
        if (c == null) return null;
        return new CustomerDto(
                c.getCustomerId(),
                c.getFirstName(),
                c.getLastName(),
                c.getEmail(),
                c.getPhone(),
                c.getStatus(),
                c.getCreatedAt()
        );
    }

    public List<CustomerDto> toDtoList(List<Customer> customers) {
        return MapperUtils.mapList(customers, this::toDto);
    }

    // ===== DTO -> Entity =====
    public Customer fromCreate(CreateCustomerDto dto) {
        if (dto == null) return null;
        Customer c = new Customer();
        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setEmail(dto.getEmail());
        // hash here so controller/service stays thin
        c.setStatus("ACTIVE");
        return c;
    }

    public void applyUpdate(UpdateCustomerDto dto, Customer entity) {
        if (dto == null || entity == null) return;
        entity.setFirstName(dto.getFirstName());
        entity.setLastName(dto.getLastName());
        entity.setPhone(dto.getPhone());
    }

    public LoginResponseDto toLoginResponse(Customer c) {
        if (c == null) return null;
        return new LoginResponseDto(
                c.getCustomerId(),
                c.getFirstName(),
                c.getLastName(),
                c.getEmail()
        );
    }
}