package Mapper;

import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import Model.Account;
import Model.Branch;
import Model.Customer;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AccountMapper {

    public AccountDto toDto(Account a) {
        if (a == null) return null;
        Long id = a.getAccount_id() != null ? a.getAccount_id() : null;
        Long customerId = a.getCustomer() != null ? a.getCustomer().getCustomerId() : null;
        String accountNumber = a.getAccount_number();
        BigDecimal balance = a.getBalance() != null ? a.getBalance() : BigDecimal.ZERO;
        return new AccountDto(
                id,
                customerId,
                accountNumber,
                a.getAccount_type(),
                a.getCurrency(),
                balance,
                a.getStatus()
        );
    }

    public List<AccountDto> toDtoList(List<Account> accounts) {
        if (accounts == null || accounts.isEmpty()) return new ArrayList<>();
        List<AccountDto> out = new ArrayList<>(accounts.size());
        for (Account a : accounts) {
            out.add(toDto(a));
        }
        return out;
    }

    public Account fromCreate(CreateAccountDto dto, Customer customer, Branch branch, String generatedAccountNumber) {
        if (dto == null) return null;
        Account a = new Account();
        a.setCustomer(customer);
        a.setBranch(branch);
        a.setAccount_number(generatedAccountNumber);
        a.setAccount_type(dto.getAccountType());
        a.setCurrency(dto.getCurrency());
        a.setBalance(dto.getInitialDeposit() != null ? dto.getInitialDeposit() : BigDecimal.ZERO);
        a.setStatus("OPEN");
        a.setOpened_at(LocalDateTime.now());
        return a;
    }

    public void applyUpdate(UpdateAccountDto dto, Account entity) {
        if (dto == null || entity == null) return;
        if (dto.getAccountType() != null) entity.setAccount_type(dto.getAccountType());
        if (dto.getStatus() != null) entity.setStatus(dto.getStatus());
    }
}
