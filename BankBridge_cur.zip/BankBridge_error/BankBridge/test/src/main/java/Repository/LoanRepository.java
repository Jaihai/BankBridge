package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.Loan;

public interface LoanRepository extends JpaRepository<Loan,Long>{

}
