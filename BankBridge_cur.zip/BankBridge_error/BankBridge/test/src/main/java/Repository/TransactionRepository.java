package Repository;

import Model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    @Query("select t from Transaction t where t.posted_at between :from and :to order by t.posted_at desc")
    List<Transaction> findAllBetween(LocalDateTime from, LocalDateTime to);
}