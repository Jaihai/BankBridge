package config; // <-- adjust to be a subpackage of your main app package

import javax.swing.text.PasswordView;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityBeans {
    @Bean
    public PasswordView passwordEncoder() {
        return new PasswordView(null);
    }
}