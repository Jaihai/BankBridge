package ExceptionHandler;


import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;

@RestControllerAdvice
public class GlobalExceptionHandler {

    static class ErrorBody {
        private final String timeStamp;
        private final String message;
        public ErrorBody(String timeStamp, String message) {
            this.timeStamp = timeStamp; this.message = message;
        }
        public String getTimeStamp() { return timeStamp; }
        public String getMessage() { return message; }
    }

    // Customize these to your custom exceptions too
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorBody> badRequest(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorBody> generic(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorBody> fallback(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorBody(LocalDate.now().toString(), "Unexpected error: " + ex.getMessage()));
    }
}