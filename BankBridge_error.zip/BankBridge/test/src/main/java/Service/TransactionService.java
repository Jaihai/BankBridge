package Service;


import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionService {
    String deposit(DepositRequest req);
    String withdraw(WithdrawRequest req);
    String fundTransfer(FundTransferRequest req);
    List<TransactionDto> summary(LocalDateTime from, LocalDateTime to);
}