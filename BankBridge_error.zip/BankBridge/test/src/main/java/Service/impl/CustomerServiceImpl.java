package Service.impl;

import Service.CustomerService;
import Mapper.AccountMapper;
import Mapper.AddressMapper;
import Model.Account;
import Model.Customer;
import Repository.AccountRepository;
import Repository.CustomerRepository;
import dto.*;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepo;
    private final AccountRepository accountRepo;
    private final PasswordEncoder passwordEncoder;
    private final AccountMapper accountMapper;
    private final AddressMapper addressMapper;

    public CustomerServiceImpl(CustomerRepository customerRepo,
                               AccountRepository accountRepo,
                               PasswordEncoder passwordEncoder,
                               AccountMapper accountMapper,
                               AddressMapper addressMapper) {
        this.customerRepo = customerRepo;
        this.accountRepo = accountRepo;
        this.passwordEncoder = passwordEncoder;
        this.accountMapper = accountMapper;
        this.addressMapper = addressMapper;
    }

    @Override
    public Long create(CreateCustomerDto dto) {
        // Email uniqueness check
        customerRepo.findByEmail(dto.getEmail()).ifPresent(x -> {
            throw new IllegalArgumentException("Email already exists");
        });

        Customer c = new Customer();
        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setEmail(dto.getEmail());
        // store hash (or raw for now if you don't wire PasswordEncoder)
        c.setPasswordHash(passwordEncoder != null ? passwordEncoder.encode(dto.getPassword())
                                                  : dto.getPassword());
        c.setStatus("ACTIVE");

        Customer saved = customerRepo.save(c);
        return extractCustomerId(saved);
    }

    @Override
    public void update(Long id, UpdateCustomerDto dto) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + id));
        c.setFirstName(dto.getFirstName());
        c.setLastName(dto.getLastName());
        c.setPhone(dto.getPhone());
        customerRepo.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CustomerDto> listAll() {
        List<Customer> customers = customerRepo.findAll();
        if (customers.isEmpty()) {
            throw new RuntimeException("No customers available");
        }
        return customers.stream().map(this::toCustomerDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDto get(Long id) {
        Customer c = customerRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + id));
        return toCustomerDto(c);
    }

    @Override
    public void delete(Long id) {
        customerRepo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public LoginResponseDto login(LoginRequestDto dto) {
        Customer c = customerRepo.findByEmail(dto.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        boolean ok = (passwordEncoder != null)
                ? passwordEncoder.matches(dto.getPassword(), c.getPasswordHash())
                : Objects.equals(dto.getPassword(), c.getPasswordHash());

        if (!ok) throw new RuntimeException("Invalid email or password");

        return new LoginResponseDto(extractCustomerId(c), c.getFirstName(), c.getLastName(), c.getEmail());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> getAllAccounts(Long customerId) {
        // ensure customer exists
        customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));

        // repository should have: List<Account> findAllByCustomerId(Long customerId)
        List<Account> accounts = accountRepo.findAllByCustomerId(customerId);
        return accountMapper.toDtoList(accounts);
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findAddress(Long customerId) {
        Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found: " + customerId));
        return addressMapper.toDto(c);
    }

    // --- helpers ---
    private CustomerDto toCustomerDto(Customer c) {
        return new CustomerDto(
                extractCustomerId(c),
                c.getFirstName(),
                c.getLastName(),
                c.getEmail(),
                c.getPhone(),
                c.getStatus(),
                c.getCreatedAt()
        );
    }

    private Long extractCustomerId(Customer c) {
        // If your entity uses Long id:
        try {
            Object val = c.getClass().getMethod("getId").invoke(c);
            if (val instanceof Long l) return l;
            if (val instanceof Integer i) return i.longValue();
        } catch (Throwable ignored) {}

        // If your entity uses Integer customer_id (snake_case)
        try {
            Object val = c.getClass().getMethod("getCustomer_id").invoke(c);
            if (val instanceof Long l) return l;
            if (val instanceof Integer i) return i.longValue();
        } catch (Throwable ignored) {}

        // If your entity uses camelCase getCustomerId()
        try {
            Object val = c.getClass().getMethod("getCustomerId").invoke(c);
            if (val instanceof Long l) return l;
            if (val instanceof Integer i) return i.longValue();
        } catch (Throwable ignored) {}

        return null;
    }
}