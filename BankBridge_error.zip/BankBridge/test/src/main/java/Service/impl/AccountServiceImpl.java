
package Service.impl;
import Repository.AccountRepository;
import Repository.CustomerRepository;
import Service.AccountService;
import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import Mapper.AccountMapper;
import Model.Account;
import Model.Customer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepo;
    private final CustomerRepository customerRepo;
    private final AccountMapper mapper;

    public AccountServiceImpl(AccountRepository accountRepo, CustomerRepository customerRepo, AccountMapper mapper) {
        this.accountRepo = accountRepo;
        this.customerRepo = customerRepo;
        this.mapper = mapper;
    }

    public Long create(CreateAccountDto dto) {
        Customer customer = customerRepo.findById(dto.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found: " + dto.getCustomerId()));
        String genNumber = UUID.randomUUID().toString(); // or your generator
        Account entity = mapper.fromCreate(dto, customer, genNumber);
        return accountRepo.save(entity).getAccount_id().longValue();
    }


@Override
public void update(Long id, UpdateAccountDto dto) {
    Account entity = accountRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Account not found: " + id));
    mapper.applyUpdate(dto, entity);
    accountRepo.save(entity);
}


@Override
@Transactional(readOnly = true)
public AccountDto get(Long id) {
    return accountRepo.findById(id)
            .map(mapper::toDto)
            .orElseThrow(() -> new RuntimeException("Account not found: " + id));
}

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> listAll() {
        return mapper.toDtoList(accountRepo.findAll());
    }


@Override
public void delete(Long id) {
    accountRepo.deleteById(id);
}

}