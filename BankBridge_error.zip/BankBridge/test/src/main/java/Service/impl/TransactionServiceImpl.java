package Service.impl;

import Service.TransactionService;
import Mapper.TransactionMapper;
import Model.Account;
import Model.Transaction;
import Repository.AccountRepository;
import Repository.TransactionRepository;
import dto.DepositRequest;
import dto.FundTransferRequest;
import dto.TransactionDto;
import dto.WithdrawRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository accountRepo;
    private final TransactionRepository txnRepo;
    private final TransactionMapper mapper;

    public TransactionServiceImpl(AccountRepository accountRepo,
                                  TransactionRepository txnRepo,
                                  TransactionMapper mapper) {
        this.accountRepo = accountRepo;
        this.txnRepo = txnRepo;
        this.mapper = mapper;
    }

    @Override
    public String deposit(DepositRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new RuntimeException("Account not found: " + req.getAccountNumber()));

        double newBal = (a.getBalance() == null ? 0.0d : a.getBalance()) + req.getAmount().doubleValue();
        a.setBalance(newBal);

        Transaction t = mapper.creditFromDeposit(a, req);
        t.setBalance_after(newBal);

        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Created Successfully";
    }

    @Override
    public String withdraw(WithdrawRequest req) {
        Account a = accountRepo.findByAccountNumber(req.getAccountNumber())
                .orElseThrow(() -> new RuntimeException("Account not found: " + req.getAccountNumber()));

        double current = (a.getBalance() == null ? 0.0d : a.getBalance());
        double delta = req.getAmount().doubleValue();
        if (current < delta) {
            throw new RuntimeException("Insufficient balance");
        }

        double newBal = current - delta;
        a.setBalance(newBal);

        Transaction t = mapper.debitFromWithdraw(a, req);
        t.setBalance_after(newBal);

        txnRepo.save(t);
        accountRepo.save(a);
        return "Record Modified Successfully";
    }

    @Override
    public String fundTransfer(FundTransferRequest req) {
        Account from = accountRepo.findByAccountNumber(req.getFromAccountNumber())
                .orElseThrow(() -> new RuntimeException("From account not found: " + req.getFromAccountNumber()));
        Account to = accountRepo.findByAccountNumber(req.getToAccountNumber())
                .orElseThrow(() -> new RuntimeException("To account not found: " + req.getToAccountNumber()));

        double amount = req.getAmount().doubleValue();
        double fromBal = (from.getBalance() == null ? 0.0d : from.getBalance());
        if (fromBal < amount) {
            throw new RuntimeException("Insufficient balance");
        }

        // debit from
        from.setBalance(fromBal - amount);
        Transaction debit = mapper.debitFromTransfer(from, req);
        debit.setBalance_after(from.getBalance());

        // credit to
        double toBal = (to.getBalance() == null ? 0.0d : to.getBalance()) + amount;
        to.setBalance(toBal);
        Transaction credit = mapper.creditFromTransfer(to, req);
        credit.setBalance_after(to.getBalance());

        txnRepo.save(debit);
        txnRepo.save(credit);
        accountRepo.save(from);
        accountRepo.save(to);

        return "Record Modified Successfully";
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> summary(LocalDateTime from, LocalDateTime to) {
        // Ensure your repository matches the timestamp type on your entity.
        return mapper.toDtoList(txnRepo.findAllBetween(from, to));
    }
}