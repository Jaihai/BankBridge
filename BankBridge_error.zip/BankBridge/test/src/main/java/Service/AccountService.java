
package Service;

import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import java.util.List;

public interface AccountService {
    Long create(CreateAccountDto dto);
    void update(Long id, UpdateAccountDto dto);
    AccountDto get(Long id);
    List<AccountDto> listAll();
    void delete(Long id);
}