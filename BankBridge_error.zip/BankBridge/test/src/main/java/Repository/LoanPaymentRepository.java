package Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Model.LoanPayment;

public interface LoanPaymentRepository extends JpaRepository<LoanPayment,Long> {

}
