package Controller;

import Service.AccountService;
import dto.AccountDto;
import dto.CreateAccountDto;
import dto.UpdateAccountDto;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bankapi/v1/account")
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) { this.accountService = accountService; }

    // POST /bankapi/v1/account - Add new account
    @PostMapping
    public ResponseEntity<String> create(@Valid @RequestBody CreateAccountDto dto) {
        accountService.create(dto);
        return ResponseEntity.status(201).body("Record Created Successfully");
    }

    // PUT /bankapi/v1/account - Modify the account (type/status)
    @PutMapping
    public ResponseEntity<String> update(@RequestParam Long id, @Valid @RequestBody UpdateAccountDto dto) {
        accountService.update(id, dto);
        return ResponseEntity.ok("Record Modified Successfully");
    }

    // GET /bankapi/v1/account - List all accounts
    @GetMapping
    public ResponseEntity<List<AccountDto>> listAll() {
        return ResponseEntity.ok(accountService.listAll());
    }

    // DELETE /bankapi/v1/account/{id} - Delete account by id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        accountService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // GET /bankapi/v1/account/{id} - Get account by id
    @GetMapping("/{id}")
    public ResponseEntity<AccountDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(accountService.get(id));
    }
}