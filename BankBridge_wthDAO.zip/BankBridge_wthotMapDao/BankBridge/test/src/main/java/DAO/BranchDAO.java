package DAO;

import Model.Branch;
import java.util.Optional;

public interface BranchDAO {
    Branch save(Branch branch);
    Optional<Branch> findById(Long id);
}
