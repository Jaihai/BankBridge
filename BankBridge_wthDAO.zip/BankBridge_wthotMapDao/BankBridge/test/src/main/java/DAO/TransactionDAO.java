package DAO;

import Model.Transaction;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionDAO {
    Transaction save(Transaction transaction);
    List<Transaction> findAllBetween(LocalDateTime from, LocalDateTime to);
    List<Transaction> findAll();
}
