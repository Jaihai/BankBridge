package DAO;

import Model.Account;
import java.util.List;
import java.util.Optional;

public interface AccountDAO {
    Account save(Account account);
    Optional<Account> findById(Long id);
    Optional<Account> findByAccountNumber(String accountNumber);
    List<Account> findAllByCustomerId(Long customerId);
    List<Account> findAll();
    void deleteById(Long id);
}
