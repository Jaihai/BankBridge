package Service.impl;

import Service.AddressService;
import Model.Customer;
import DAO.CustomerDAO;
import dto.AddressDto;
import dto.CreateAddressDto;
import dto.UpdateAddressDto;
import exception.AddressDetailsNotFoundException;
import exception.CustomerIDNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class AddressServiceImpl implements AddressService {

    private final CustomerDAO customerDAO;

    public AddressServiceImpl(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
    }

    @Override
    public Long create(CreateAddressDto dto) {
        Customer c = customerDAO.findById(dto.getCustomerId())
                .orElseThrow(() -> new CustomerIDNotFoundException(dto.getCustomerId()));
        c.setAddress_line(dto.getAddressLine());
        c.setCity(dto.getCity());
        c.setState(dto.getState());
        c.setPostal_code(dto.getPostalCode());
        c.setCountry(dto.getCountry());
        customerDAO.save(c);
        return c.getCustomerId();
    }

    @Override
    public void updateByCustomerId(Long customerId, UpdateAddressDto dto) {
        Customer c = customerDAO.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        c.setAddress_line(dto.getAddressLine());
        c.setCity(dto.getCity());
        c.setState(dto.getState());
        c.setPostal_code(dto.getPostalCode());
        c.setCountry(dto.getCountry());
        customerDAO.save(c);
    }

    @Override
    public void deleteByCustomerId(Long customerId) {
        Customer c = customerDAO.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        c.setAddress_line(null);
        c.setCity(null);
        c.setState(null);
        c.setPostal_code(null);
        c.setCountry(null);
        customerDAO.save(c);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AddressDto> listAll() {
        return customerDAO.findAll().stream()
                .filter(c -> c.getAddress_line() != null || c.getCity() != null || c.getCountry() != null)
                .map(c -> {
                    AddressDto dto = new AddressDto();
                    dto.setCustomerId(c.getCustomerId());
                    dto.setAddressLine(c.getAddress_line());
                    dto.setCity(c.getCity());
                    dto.setState(c.getState());
                    dto.setPostalCode(c.getPostal_code());
                    dto.setCountry(c.getCountry());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AddressDto findByCustomerId(Long customerId) {
        Customer c = customerDAO.findById(customerId)
                .orElseThrow(() -> new CustomerIDNotFoundException(customerId));
        if (c.getAddress_line() == null && c.getCity() == null && c.getState() == null
                && c.getPostal_code() == null && c.getCountry() == null) {
            throw new AddressDetailsNotFoundException(customerId);
        }
        AddressDto dto = new AddressDto();
        dto.setCustomerId(c.getCustomerId());
        dto.setAddressLine(c.getAddress_line());
        dto.setCity(c.getCity());
        dto.setState(c.getState());
        dto.setPostalCode(c.getPostal_code());
        dto.setCountry(c.getCountry());
        return dto;
    }
}
