package ExceptionHandler;

import exception.*;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDate;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    static class ErrorBody {
        private final String timeStamp;
        private final String message;

        public ErrorBody(String timeStamp, String message) {
            this.timeStamp = timeStamp;
            this.message = message;
        }

        public String getTimeStamp() {
            return timeStamp;
        }

        public String getMessage() {
            return message;
        }
    }

    @ExceptionHandler(CustomerIDNotFoundException.class)
    public ResponseEntity<ErrorBody> handleCustomerNotFound(CustomerIDNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(InvalidLoginException.class)
    public ResponseEntity<ErrorBody> handleInvalidLogin(InvalidLoginException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(CustomerDBEmptyException.class)
    public ResponseEntity<ErrorBody> handleCustomerDBEmpty(CustomerDBEmptyException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(AddressDetailsNotFoundException.class)
    public ResponseEntity<ErrorBody> handleAddressNotFound(AddressDetailsNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(InSufficientBalanceException.class)
    public ResponseEntity<ErrorBody> handleInsufficientBalance(InSufficientBalanceException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<ErrorBody> handleAccountNotFound(AccountNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(AccountCloseException.class)
    public ResponseEntity<ErrorBody> handleAccountClose(AccountCloseException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorBody> handleValidation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorBody(LocalDate.now().toString(), "Validation failed: " + msg));
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorBody> handleConstraintViolation(ConstraintViolationException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorBody(LocalDate.now().toString(), "Validation failed: " + ex.getMessage()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorBody> badRequest(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorBody> generic(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorBody(LocalDate.now().toString(), ex.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorBody> fallback(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorBody(LocalDate.now().toString(), "Unexpected error: " + ex.getMessage()));
    }
}
