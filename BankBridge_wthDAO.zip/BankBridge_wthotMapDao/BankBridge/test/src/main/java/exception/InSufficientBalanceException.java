package exception;

public class InSufficientBalanceException extends RuntimeException {
    public InSufficientBalanceException() {
        super("Insufficient balance");
    }
    public InSufficientBalanceException(String message) {
        super(message);
    }
}
